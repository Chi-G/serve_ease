
  # Food Ordering Web App

  This is a code bundle for Food Ordering Web App. The original project is available at https://www.figma.com/design/s4sF7tStODXt7xnspvWWQV/Food-Ordering-Web-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  