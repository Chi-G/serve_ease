import { useState, useEffect } from 'react';
import { Menu } from './components/Menu';
import { GroupCart } from './components/GroupCart';
import { Checkout } from './components/Checkout';
import { OrderTracking } from './components/OrderTracking';
import { KitchenDisplay } from './components/KitchenDisplay';
import { WelcomeScreen } from './components/WelcomeScreen';
import { WaitTimeBanner } from './components/WaitTimeBanner';
import { Bell } from 'lucide-react';

export type ServiceType = 'eat-in' | 'take-away';

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  serviceType: ServiceType;
  image: string;
  isProtein?: boolean;
  customerName: string;
}

export interface Order {
  id: string;
  tableNumber: number;
  items: CartItem[];
  total: number;
  status: 'pending' | 'paid' | 'in-kitchen' | 'ready';
  paymentMethod?: 'card' | 'transfer';
  tokenNumber?: string;
  timestamp: number;
  estimatedTime?: number;
}

export default function App() {
  const [view, setView] = useState<'welcome' | 'menu' | 'cart' | 'checkout' | 'tracking' | 'kds'>('welcome');
  const [tableNumber] = useState(12);
  const [customerNames, setCustomerNames] = useState<string[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [allOrders, setAllOrders] = useState<Order[]>([]);
  const [currentCustomerIndex, setCurrentCustomerIndex] = useState(0);
  const [hasOrderedForAll, setHasOrderedForAll] = useState(false);
  const [bannerDismissed, setBannerDismissed] = useState(false);

  useEffect(() => {
    const savedNames = localStorage.getItem('customerNames');
    const savedCart = localStorage.getItem('cart');
    const savedOrder = localStorage.getItem('currentOrder');

    if (savedNames) setCustomerNames(JSON.parse(savedNames));
    if (savedCart) setCart(JSON.parse(savedCart));
    if (savedOrder) setCurrentOrder(JSON.parse(savedOrder));
  }, []);

  useEffect(() => {
    if (customerNames.length > 0) {
      localStorage.setItem('customerNames', JSON.stringify(customerNames));
    }
  }, [customerNames]);

  useEffect(() => {
    if (cart.length > 0) {
      localStorage.setItem('cart', JSON.stringify(cart));
    }
  }, [cart]);

  useEffect(() => {
    if (currentOrder) {
      localStorage.setItem('currentOrder', JSON.stringify(currentOrder));
    }
  }, [currentOrder]);

  const addToCart = (item: Omit<CartItem, 'customerName'>) => {
    setCart(prev => [...prev, { ...item, customerName: customerNames[currentCustomerIndex] }]);
  };

  const removeFromCart = (itemId: string) => {
    setCart(prev => prev.filter(item => item.id !== itemId));
  };

  const handleNamesSubmit = (names: string[]) => {
    setCustomerNames(names);
    setView('menu');
  };

  const handleCheckout = () => {
    if (currentCustomerIndex < customerNames.length - 1 && !hasOrderedForAll) {
      setCurrentCustomerIndex(prev => prev + 1);
      setView('menu');
    } else {
      setView('checkout');
      setHasOrderedForAll(true);
    }
  };

  const handlePayment = (method: 'card' | 'transfer') => {
    const tokenNumber = `#${String(Math.floor(Math.random() * 999) + 1).padStart(3, '0')}`;
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const estimatedTime = 15;

    const order: Order = {
      id: Date.now().toString(),
      tableNumber,
      items: cart,
      total,
      status: method === 'card' ? 'in-kitchen' : 'pending',
      paymentMethod: method,
      tokenNumber,
      timestamp: Date.now(),
      estimatedTime
    };

    setCurrentOrder(order);
    setAllOrders(prev => [...prev, order]);
    setView('tracking');

    if (method === 'card') {
      setTimeout(() => {
        setCurrentOrder(prev => prev ? { ...prev, status: 'in-kitchen' } : null);
      }, 2000);
    }
  };

  const handleBackToMenu = () => {
    setView('menu');
  };

  const handleCallWaiter = () => {
    alert('Waiter has been called!');
  };

  const handlePlaceNewOrder = () => {
    localStorage.clear();
    setCart([]);
    setCustomerNames([]);
    setCurrentOrder(null);
    setCurrentCustomerIndex(0);
    setHasOrderedForAll(false);
    setBannerDismissed(false);
    setView('welcome');
  };

  const handleAddMoreItems = () => {
    setView('menu');
  };

  const currentCustomerName = customerNames[currentCustomerIndex] || '';
  const currentCustomerItems = cart.filter(item => item.customerName === currentCustomerName);

  const showWaitTimeBanner = currentOrder && currentOrder.status === 'in-kitchen' && !bannerDismissed && view !== 'tracking' && view !== 'kds';

  return (
    <div className="min-h-screen bg-background text-foreground">
      {showWaitTimeBanner && (
        <WaitTimeBanner
          order={currentOrder}
          onDismiss={() => setBannerDismissed(true)}
          onNavigate={() => setView('tracking')}
        />
      )}

      {view === 'welcome' && (
        <WelcomeScreen
          tableNumber={tableNumber}
          onSubmit={handleNamesSubmit}
          onNavigateToKDS={() => setView('kds')}
        />
      )}

      {view === 'menu' && (
        <div>
          <div className="sticky top-0 z-50 bg-card/95 backdrop-blur-sm border-b border-border">
            <div className="flex items-center justify-between px-4 py-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Table {tableNumber}</span>
                </div>
                <p className="text-sm">Ordering for: <span style={{ color: '#FF5C00' }}>{currentCustomerName}</span></p>
                {customerNames.length > 1 && (
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex-1 h-1 bg-secondary rounded-full overflow-hidden">
                      <div
                        className="h-full transition-all duration-300"
                        style={{
                          backgroundColor: '#FF5C00',
                          width: `${((currentCustomerIndex + 1) / customerNames.length) * 100}%`
                        }}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground whitespace-nowrap">
                      {currentCustomerIndex + 1}/{customerNames.length}
                    </p>
                  </div>
                )}
              </div>
              <button
                onClick={handleCallWaiter}
                className="p-3 rounded-full"
                style={{ backgroundColor: '#FF5C00' }}
              >
                <Bell size={20} className="text-white" />
              </button>
            </div>
          </div>

          <Menu addToCart={addToCart} />

          {currentCustomerItems.length > 0 && (
            <div className="fixed bottom-0 left-0 right-0 p-4 bg-card/95 backdrop-blur-sm border-t border-border">
              <button
                onClick={() => setView('cart')}
                className="w-full py-4 rounded-2xl text-white"
                style={{ backgroundColor: '#FF5C00' }}
              >
                View Cart ({currentCustomerItems.length} items)
              </button>
            </div>
          )}
        </div>
      )}

      {view === 'cart' && (
        <GroupCart
          cart={cart}
          customerNames={customerNames}
          currentCustomerName={currentCustomerName}
          currentCustomerIndex={currentCustomerIndex}
          removeFromCart={removeFromCart}
          onContinue={handleCheckout}
          onBackToMenu={handleBackToMenu}
          isLastCustomer={currentCustomerIndex === customerNames.length - 1 || hasOrderedForAll}
        />
      )}

      {view === 'checkout' && (
        <Checkout
          cart={cart}
          customerNames={customerNames}
          onPayment={handlePayment}
          onBack={() => setView('cart')}
        />
      )}

      {view === 'tracking' && currentOrder && (
        <OrderTracking
          order={currentOrder}
          onPlaceNewOrder={handlePlaceNewOrder}
          onAddMoreItems={handleAddMoreItems}
          onCallWaiter={handleCallWaiter}
          onUpdateStatus={(status) => setCurrentOrder(prev => prev ? { ...prev, status } : null)}
        />
      )}

      {view === 'kds' && (
        <KitchenDisplay orders={allOrders} onUpdateOrder={(orderId, updates) => {
          setAllOrders(prev => prev.map(o => o.id === orderId ? { ...o, ...updates } : o));
        }} />
      )}

      {view !== 'kds' && (
        <button
          onClick={() => setView('kds')}
          className="fixed bottom-4 right-4 px-4 py-2 rounded-lg bg-secondary text-secondary-foreground text-xs opacity-50 hover:opacity-100 transition-opacity"
        >
          KDS
        </button>
      )}
    </div>
  );
}
