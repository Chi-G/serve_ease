import { useState } from 'react';
import { Search, ChevronLeft, ChevronRight } from 'lucide-react';
import { ProductModal } from './ProductModal';
import type { CartItem, ServiceType } from '../App';

interface MenuItem {
  id: string;
  name: string;
  price: number;
  category: string;
  image: string;
  inStock: boolean;
}

const MENU_ITEMS: MenuItem[] = [
  { id: '1', name: 'Jollof Rice', price: 3500, category: 'Meals', image: 'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?w=400', inStock: true },
  { id: '2', name: 'Fried Rice', price: 3500, category: 'Meals', image: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=400', inStock: true },
  { id: '3', name: 'Rice & Stew', price: 3000, category: 'Meals', image: 'https://images.unsplash.com/photo-1516684732162-798a0062be99?w=400', inStock: true },
  { id: '4', name: 'Coconut Rice', price: 4000, category: 'Meals', image: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=400', inStock: true },
  { id: '5', name: 'Grilled Chicken', price: 2500, category: 'Proteins', image: 'https://images.unsplash.com/photo-1598103442097-8b74394b95c6?w=400', inStock: true },
  { id: '6', name: 'Fried Chicken', price: 2500, category: 'Proteins', image: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=400', inStock: true },
  { id: '7', name: 'Beef Steak', price: 3500, category: 'Proteins', image: 'https://images.unsplash.com/photo-1558030006-450675393462?w=400', inStock: true },
  { id: '8', name: 'Grilled Fish', price: 3000, category: 'Proteins', image: 'https://images.unsplash.com/photo-1580476262798-bddd9f4b7369?w=400', inStock: true },
  { id: '9', name: 'Fried Plantain', price: 1000, category: 'Sides', image: 'https://images.unsplash.com/photo-1604329760661-e71dc83f8f26?w=400', inStock: true },
  { id: '10', name: 'Coleslaw', price: 800, category: 'Sides', image: 'https://images.unsplash.com/photo-1625944230945-1b7dd3b949ab?w=400', inStock: true },
  { id: '11', name: 'Garden Salad', price: 1500, category: 'Sides', image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400', inStock: true },
  { id: '12', name: 'French Fries', price: 1200, category: 'Sides', image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=400', inStock: true },
  { id: '13', name: 'Chapman', price: 1500, category: 'Drinks', image: 'https://images.unsplash.com/photo-1546171753-97d7676e4602?w=400', inStock: true },
  { id: '14', name: 'Fresh Juice', price: 1200, category: 'Drinks', image: 'https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=400', inStock: true },
  { id: '15', name: 'Soft Drink', price: 500, category: 'Drinks', image: 'https://images.unsplash.com/photo-1629203851122-3726ecdf080e?w=400', inStock: true },
  { id: '16', name: 'Zobo', price: 800, category: 'Drinks', image: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=400', inStock: true },
];

const CATEGORIES = ['All', 'Meals', 'Proteins', 'Sides', 'Drinks'];
const ITEMS_PER_PAGE = 6;

interface MenuProps {
  addToCart: (item: Omit<CartItem, 'customerName'>) => void;
}

export function Menu({ addToCart }: MenuProps) {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [currentPage, setCurrentPage] = useState(1);

  const filteredItems = MENU_ITEMS.filter(item => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const totalPages = Math.ceil(filteredItems.length / ITEMS_PER_PAGE);
  const paginatedItems = filteredItems.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    setCurrentPage(1);
  };

  return (
    <div className="pb-24">
      <div className="sticky top-[73px] z-40 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="p-4 space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={20} />
            <input
              type="text"
              placeholder="Search menu..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-10 pr-4 py-3 rounded-2xl bg-input-background border border-border focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {CATEGORIES.map(category => (
              <button
                key={category}
                onClick={() => handleCategoryChange(category)}
                className="px-4 py-2 rounded-full whitespace-nowrap transition-all"
                style={{
                  backgroundColor: selectedCategory === category ? '#FF5C00' : '#2A2A2A',
                  color: selectedCategory === category ? '#ffffff' : '#A0A0A0'
                }}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="grid grid-cols-2 gap-4">
          {paginatedItems.map(item => (
            <button
              key={item.id}
              onClick={() => item.inStock && setSelectedItem(item)}
              disabled={!item.inStock}
              className="relative overflow-hidden rounded-2xl bg-card border border-border transition-transform active:scale-95 disabled:opacity-50"
            >
              <div className="aspect-square">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
              </div>

              <div className="absolute top-2 right-2">
                {item.inStock ? (
                  <span className="px-2 py-1 rounded-full text-xs bg-green-500 text-white">
                    Fresh
                  </span>
                ) : (
                  <span className="px-2 py-1 rounded-full text-xs bg-gray-500 text-white">
                    Sold Out
                  </span>
                )}
              </div>

              <div className="p-3 text-left">
                <h3 className="mb-1">{item.name}</h3>
                <p className="text-sm" style={{ color: '#FF5C00' }}>₦{item.price.toLocaleString()}</p>
              </div>
            </button>
          ))}
        </div>

        {totalPages > 1 && (
          <div className="space-y-4 mt-6">
            <div className="flex items-center justify-center gap-4">
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
                className="px-4 py-2 rounded-lg bg-secondary disabled:opacity-50 transition-all"
              >
                <ChevronLeft size={20} />
              </button>

              <div className="flex gap-2">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                  <button
                    key={page}
                    onClick={() => handlePageChange(page)}
                    className="w-2 h-2 rounded-full transition-all"
                    style={{
                      backgroundColor: currentPage === page ? '#FF5C00' : '#2A2A2A',
                      width: currentPage === page ? '24px' : '8px'
                    }}
                  />
                ))}
              </div>

              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="px-4 py-2 rounded-lg bg-secondary disabled:opacity-50 transition-all"
              >
                <ChevronRight size={20} />
              </button>
            </div>

            <p className="text-center text-sm text-muted-foreground">
              Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1}-{Math.min(currentPage * ITEMS_PER_PAGE, filteredItems.length)} of {filteredItems.length} items
            </p>
          </div>
        )}
      </div>

      {selectedItem && (
        <ProductModal
          item={selectedItem}
          onClose={() => setSelectedItem(null)}
          onAddToCart={addToCart}
        />
      )}
    </div>
  );
}
