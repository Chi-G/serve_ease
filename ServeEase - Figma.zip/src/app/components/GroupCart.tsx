import { Trash2, ArrowLeft } from 'lucide-react';
import type { CartItem } from '../App';

interface GroupCartProps {
  cart: CartItem[];
  customerNames: string[];
  currentCustomerName: string;
  currentCustomerIndex: number;
  removeFromCart: (itemId: string) => void;
  onContinue: () => void;
  onBackToMenu: () => void;
  isLastCustomer: boolean;
}

export function GroupCart({
  cart,
  customerNames,
  currentCustomerName,
  currentCustomerIndex,
  removeFromCart,
  onContinue,
  onBackToMenu,
  isLastCustomer
}: GroupCartProps) {
  const myItems = cart.filter(item => item.customerName === currentCustomerName);
  const othersItems = cart.filter(item => item.customerName !== currentCustomerName);

  const myTotal = myItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const grandTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const groupedOthers = othersItems.reduce((acc, item) => {
    if (!acc[item.customerName]) {
      acc[item.customerName] = [];
    }
    acc[item.customerName].push(item);
    return acc;
  }, {} as Record<string, CartItem[]>);

  return (
    <div className="min-h-screen bg-background pb-32">
      <div className="sticky top-0 z-50 bg-card/95 backdrop-blur-sm border-b border-border">
        <div className="px-4 py-4 space-y-3">
          <div className="flex items-center gap-3">
            <button onClick={onBackToMenu} className="p-2 rounded-full bg-secondary">
              <ArrowLeft size={20} />
            </button>
            <h1>Group Cart</h1>
          </div>

          {customerNames.length > 1 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">
                  {currentCustomerName}'s order
                </p>
                <p className="text-xs text-muted-foreground">
                  {currentCustomerIndex + 1}/{customerNames.length}
                </p>
              </div>
              <div className="h-2 bg-secondary rounded-full overflow-hidden">
                <div
                  className="h-full transition-all duration-300"
                  style={{
                    backgroundColor: '#FF5C00',
                    width: `${((currentCustomerIndex + 1) / customerNames.length) * 100}%`
                  }}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="p-4 space-y-6">
        <div className="bg-card rounded-2xl border border-border p-4">
          <div className="flex items-center justify-between mb-4">
            <h2>My Items</h2>
            <span style={{ color: '#FF5C00' }}>{currentCustomerName}</span>
          </div>

          {myItems.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">No items yet</p>
          ) : (
            <div className="space-y-3">
              {myItems.map(item => (
                <div key={item.id} className="flex gap-3 p-3 rounded-xl bg-secondary">
                  <img src={item.image} alt={item.name} className="w-16 h-16 rounded-lg object-cover" />
                  <div className="flex-1">
                    <p>{item.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {item.serviceType === 'eat-in' ? '🍽️ Eat-in' : '🥡 Take-away'}
                    </p>
                    <p className="text-sm" style={{ color: '#FF5C00' }}>
                      ₦{(item.price * item.quantity).toLocaleString()}
                      {item.quantity > 1 && <span className="text-xs text-muted-foreground"> ({item.quantity}x)</span>}
                    </p>
                  </div>
                  <button
                    onClick={() => removeFromCart(item.id)}
                    className="p-2 h-fit rounded-lg bg-destructive/20 text-destructive"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          )}

          {myItems.length > 0 && (
            <div className="mt-4 pt-4 border-t border-border flex justify-between">
              <span>Subtotal</span>
              <span style={{ color: '#FF5C00' }}>₦{myTotal.toLocaleString()}</span>
            </div>
          )}
        </div>

        {Object.keys(groupedOthers).length > 0 && (
          <div className="bg-card rounded-2xl border border-border p-4">
            <h2 className="mb-4">Table Summary</h2>

            <div className="space-y-4">
              {Object.entries(groupedOthers).map(([name, items]) => {
                const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
                return (
                  <div key={name} className="pb-4 border-b border-border last:border-b-0">
                    <p className="text-sm text-muted-foreground mb-2">{name}</p>
                    <div className="space-y-2">
                      {items.map(item => (
                        <div key={item.id} className="flex justify-between text-sm">
                          <span>
                            {item.quantity}x {item.name}
                            {item.proteins && item.proteins.length > 0 && ` + ${item.proteins.join(', ')}`}
                          </span>
                          <span>₦{item.price.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                    <p className="text-sm text-right mt-2" style={{ color: '#FF5C00' }}>
                      ₦{subtotal.toLocaleString()}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {cart.length > 0 && (
          <div className="bg-card rounded-2xl border border-border p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-lg">Grand Total</span>
              <span className="text-2xl" style={{ color: '#FF5C00' }}>
                ₦{grandTotal.toLocaleString()}
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              {customerNames.length} {customerNames.length === 1 ? 'person' : 'people'} • {cart.length} items
            </p>
          </div>
        )}
      </div>

      {myItems.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-card/95 backdrop-blur-sm border-t border-border">
          <button
            onClick={onContinue}
            className="w-full py-4 rounded-2xl text-white"
            style={{ backgroundColor: '#FF5C00' }}
          >
            {isLastCustomer ? 'Proceed to Checkout' : `Done → Next Person's Turn`}
          </button>
        </div>
      )}
    </div>
  );
}
