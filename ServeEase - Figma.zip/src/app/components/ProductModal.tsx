import { useState } from 'react';
import { X, Plus, Minus, Check } from 'lucide-react';
import type { CartItem, ServiceType } from '../App';

interface MenuItem {
  id: string;
  name: string;
  price: number;
  category: string;
  image: string;
  inStock: boolean;
}

interface ProductModalProps {
  item: MenuItem;
  onClose: () => void;
  onAddToCart: (item: Omit<CartItem, 'customerName'>) => void;
}

const AVAILABLE_PROTEINS = [
  { id: 'chicken', name: 'Grilled Chicken', price: 2500, image: 'https://images.unsplash.com/photo-1598103442097-8b74394b95c6?w=200' },
  { id: 'beef', name: 'Beef Steak', price: 3500, image: 'https://images.unsplash.com/photo-1558030006-450675393462?w=200' },
  { id: 'fish', name: 'Grilled Fish', price: 3000, image: 'https://images.unsplash.com/photo-1580476262798-bddd9f4b7369?w=200' },
];

export function ProductModal({ item, onClose, onAddToCart }: ProductModalProps) {
  const [serviceType, setServiceType] = useState<ServiceType>('eat-in');
  const [quantity, setQuantity] = useState(1);
  const [selectedProteins, setSelectedProteins] = useState<string[]>([]);

  const toggleProtein = (proteinId: string) => {
    setSelectedProteins(prev =>
      prev.includes(proteinId)
        ? prev.filter(id => id !== proteinId)
        : [...prev, proteinId]
    );
  };

  const calculateTotal = () => {
    const basePrice = item.price * quantity;
    const proteinsPrice = selectedProteins.reduce((sum, proteinId) => {
      const protein = AVAILABLE_PROTEINS.find(p => p.id === proteinId);
      return sum + (protein?.price || 0);
    }, 0);
    return basePrice + proteinsPrice;
  };

  const handleAddToCart = () => {
    onAddToCart({
      id: `${item.id}-${Date.now()}`,
      name: item.name,
      price: item.price,
      quantity,
      serviceType,
      image: item.image,
    });

    selectedProteins.forEach(proteinId => {
      const protein = AVAILABLE_PROTEINS.find(p => p.id === proteinId);
      if (protein) {
        onAddToCart({
          id: `${protein.id}-${Date.now()}-${Math.random()}`,
          name: protein.name,
          price: protein.price,
          quantity: 1,
          serviceType,
          image: protein.image,
          isProtein: true,
        });
      }
    });

    onClose();
  };

  const showProteinUpsell = item.category === 'Meals';

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />

      <div className="relative w-full max-w-lg bg-card rounded-t-3xl sm:rounded-3xl max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-background/80 backdrop-blur-sm z-10"
        >
          <X size={20} />
        </button>

        <div className="aspect-video">
          <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
        </div>

        <div className="p-6 space-y-6">
          <div>
            <h2 className="text-2xl mb-2">{item.name}</h2>
            <p className="text-xl" style={{ color: '#FF5C00' }}>₦{item.price.toLocaleString()}</p>
          </div>

          <div>
            <label className="block mb-3">Service Type</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setServiceType('eat-in')}
                className="p-4 rounded-2xl border-2 transition-all flex items-center justify-center gap-2"
                style={{
                  borderColor: serviceType === 'eat-in' ? '#FF5C00' : '#2A2A2A',
                  backgroundColor: serviceType === 'eat-in' ? 'rgba(255, 92, 0, 0.1)' : 'transparent'
                }}
              >
                <span>🍽️</span>
                <span>Eat-in</span>
              </button>
              <button
                onClick={() => setServiceType('take-away')}
                className="p-4 rounded-2xl border-2 transition-all flex items-center justify-center gap-2"
                style={{
                  borderColor: serviceType === 'take-away' ? '#FF5C00' : '#2A2A2A',
                  backgroundColor: serviceType === 'take-away' ? 'rgba(255, 92, 0, 0.1)' : 'transparent'
                }}
              >
                <span>🥡</span>
                <span>Take-away</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block mb-3">Quantity</label>
            <div className="flex items-center justify-center gap-4">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center"
              >
                <Minus size={20} />
              </button>
              <span className="text-2xl w-16 text-center">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{ backgroundColor: '#FF5C00' }}
              >
                <Plus size={20} />
              </button>
            </div>
          </div>

          {showProteinUpsell && (
            <div>
              <label className="block mb-3">Add a protein?</label>
              <div className="space-y-3">
                {AVAILABLE_PROTEINS.map(protein => {
                  const isSelected = selectedProteins.includes(protein.id);
                  return (
                    <button
                      key={protein.id}
                      onClick={() => toggleProtein(protein.id)}
                      className="w-full p-3 rounded-2xl border-2 transition-all flex items-center gap-3 relative overflow-hidden"
                      style={{
                        borderColor: isSelected ? '#FF5C00' : '#2A2A2A',
                        backgroundColor: isSelected ? 'rgba(255, 92, 0, 0.1)' : 'transparent'
                      }}
                    >
                      <div className="relative">
                        <img src={protein.image} alt={protein.name} className="w-16 h-16 rounded-xl object-cover" />
                        {isSelected && (
                          <div className="absolute inset-0 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'rgba(255, 92, 0, 0.9)' }}>
                            <Check size={32} className="text-white" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 text-left">
                        <p>{protein.name}</p>
                        <p className="text-sm text-muted-foreground">₦{protein.price.toLocaleString()}</p>
                      </div>
                      <div
                        className="w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0"
                        style={{
                          borderColor: isSelected ? '#FF5C00' : '#2A2A2A',
                          backgroundColor: isSelected ? '#FF5C00' : 'transparent'
                        }}
                      >
                        {isSelected && (
                          <Check size={16} className="text-white" />
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <button
            onClick={handleAddToCart}
            className="w-full py-4 rounded-2xl text-white"
            style={{ backgroundColor: '#FF5C00' }}
          >
            Add to Cart — ₦{calculateTotal().toLocaleString()}
          </button>
        </div>
      </div>
    </div>
  );
}
