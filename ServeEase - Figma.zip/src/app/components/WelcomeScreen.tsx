import { useState } from 'react';
import { Plus, X, ChefHat } from 'lucide-react';

interface WelcomeScreenProps {
  tableNumber: number;
  onSubmit: (names: string[]) => void;
  onNavigateToKDS: () => void;
}

const AVATAR_COLORS = [
  '#FF5C00', '#FFA500', '#FFD700', '#FF6347', '#FF8C00',
  '#FF4500', '#FF7F50', '#FFA07A'
];

export function WelcomeScreen({ tableNumber, onSubmit, onNavigateToKDS }: WelcomeScreenProps) {
  const [names, setNames] = useState<string[]>([]);
  const [currentInput, setCurrentInput] = useState('');

  const addName = () => {
    if (currentInput.trim() && names.length < 8) {
      setNames([...names, currentInput.trim()]);
      setCurrentInput('');
    }
  };

  const removeName = (index: number) => {
    setNames(names.filter((_, i) => i !== index));
  };

  const handleSubmit = () => {
    if (names.length > 0) {
      onSubmit(names);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addName();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{
      backgroundImage: 'url(https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1200)',
      backgroundSize: 'cover',
      backgroundPosition: 'center'
    }}>
      <div className="w-full max-w-md backdrop-blur-xl bg-card/80 p-8 rounded-3xl border border-border shadow-2xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl mb-2" style={{ color: '#FF5C00' }}>ServeEase</h1>
          <p className="text-muted-foreground">Table {tableNumber}</p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block mb-2 text-sm">Add Guest Names</label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Enter a name"
                value={currentInput}
                onChange={(e) => setCurrentInput(e.target.value)}
                onKeyDown={handleKeyDown}
                className="flex-1 px-4 py-3 rounded-2xl bg-input-background border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                maxLength={20}
                disabled={names.length >= 8}
              />
              <button
                onClick={addName}
                disabled={!currentInput.trim() || names.length >= 8}
                className="p-3 rounded-2xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                style={{ backgroundColor: '#FF5C00' }}
              >
                <Plus size={24} className="text-white" />
              </button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {names.length}/8 guests added
            </p>
          </div>

          {names.length > 0 && (
            <div className="space-y-2">
              {names.map((name, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 p-3 rounded-2xl bg-secondary/50 border border-border"
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white flex-shrink-0"
                    style={{ backgroundColor: AVATAR_COLORS[index] }}
                  >
                    {name.charAt(0).toUpperCase()}
                  </div>
                  <span className="flex-1">{name}</span>
                  <button
                    onClick={() => removeName(index)}
                    className="p-1 rounded-full hover:bg-destructive/20 text-destructive transition-colors"
                  >
                    <X size={18} />
                  </button>
                </div>
              ))}
            </div>
          )}

          <button
            onClick={handleSubmit}
            disabled={names.length === 0}
            className="w-full py-4 rounded-2xl text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            style={{ backgroundColor: '#FF5C00' }}
          >
            See Menu
          </button>
        </div>

        <div className="mt-8 pt-6 border-t border-border">
          <button
            onClick={onNavigateToKDS}
            className="w-full flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ChefHat size={16} />
            <span>Staff: Kitchen Display</span>
          </button>
        </div>
      </div>
    </div>
  );
}
