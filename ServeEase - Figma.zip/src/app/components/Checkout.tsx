import { useState } from 'react';
import { ArrowLeft, CreditCard, Building2, Copy, Check } from 'lucide-react';
import type { CartItem } from '../App';

interface CheckoutProps {
  cart: CartItem[];
  customerNames: string[];
  onPayment: (method: 'card' | 'transfer') => void;
  onBack: () => void;
}

export function Checkout({ cart, customerNames, onPayment, onBack }: CheckoutProps) {
  const [selectedMethod, setSelectedMethod] = useState<'card' | 'transfer' | null>(null);
  const [copied, setCopied] = useState(false);

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const accountNumber = '0123456789';
  const bankName = 'ServeEase Bank';

  const handleCopy = () => {
    navigator.clipboard.writeText(accountNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const loyaltyPoints = Math.floor(total / 100);

  const groupedByCustomer = cart.reduce((acc, item) => {
    if (!acc[item.customerName]) {
      acc[item.customerName] = [];
    }
    acc[item.customerName].push(item);
    return acc;
  }, {} as Record<string, CartItem[]>);

  return (
    <div className="min-h-screen bg-background pb-32">
      <div className="sticky top-0 z-50 bg-card/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center gap-3 px-4 py-4">
          <button onClick={onBack} className="p-2 rounded-full bg-secondary">
            <ArrowLeft size={20} />
          </button>
          <h1>Checkout</h1>
        </div>
      </div>

      <div className="p-4 space-y-6">
        <div className="bg-card rounded-2xl border border-border p-6 text-center">
          <p className="text-sm text-muted-foreground mb-2">Total Amount</p>
          <p className="text-5xl mb-4" style={{ color: '#FF5C00' }}>
            ₦{total.toLocaleString()}
          </p>
          {customerNames.length > 1 && (
            <div className="flex flex-wrap gap-2 justify-center mb-4">
              {Object.entries(groupedByCustomer).map(([name, items]) => {
                const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
                return (
                  <div key={name} className="px-3 py-1 rounded-full bg-secondary text-xs">
                    {name}: ₦{subtotal.toLocaleString()}
                  </div>
                );
              })}
            </div>
          )}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/20">
            <span className="text-sm">Earn {loyaltyPoints} Forahia Points!</span>
          </div>
        </div>

        <div className="bg-card rounded-2xl border border-border p-4">
          <h3 className="mb-3">Order Summary</h3>
          <div className="space-y-4">
            {Object.entries(groupedByCustomer).map(([name, items]) => {
              const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
              return (
                <div key={name} className="pb-4 border-b border-border last:border-b-0">
                  <p className="text-sm mb-2" style={{ color: '#FF5C00' }}>{name}</p>
                  <div className="space-y-2">
                    {items.map(item => (
                      <div key={item.id} className="flex justify-between text-sm">
                        <span className="flex items-center gap-2">
                          <span>{item.serviceType === 'eat-in' ? '🍽️' : '🥡'}</span>
                          <span>{item.quantity}x {item.name}</span>
                        </span>
                        <span>₦{(item.price * item.quantity).toLocaleString()}</span>
                      </div>
                    ))}
                  </div>
                  <p className="text-sm text-right mt-2 text-muted-foreground">
                    ₦{subtotal.toLocaleString()}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        <div>
          <h2 className="mb-4">Select Payment Method</h2>

          <div className="space-y-3">
            <button
              onClick={() => setSelectedMethod('card')}
              className="w-full p-4 rounded-2xl border-2 transition-all flex items-center gap-4"
              style={{
                borderColor: selectedMethod === 'card' ? '#FF5C00' : '#2A2A2A',
                backgroundColor: selectedMethod === 'card' ? 'rgba(255, 92, 0, 0.1)' : 'transparent'
              }}
            >
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{ backgroundColor: '#FF5C00' }}
              >
                <CreditCard size={24} className="text-white" />
              </div>
              <div className="flex-1 text-left">
                <p>Card / USSD</p>
                <p className="text-sm text-muted-foreground">Instant payment</p>
              </div>
            </button>

            <button
              onClick={() => setSelectedMethod('transfer')}
              className="w-full p-4 rounded-2xl border-2 transition-all flex items-center gap-4"
              style={{
                borderColor: selectedMethod === 'transfer' ? '#FF5C00' : '#2A2A2A',
                backgroundColor: selectedMethod === 'transfer' ? 'rgba(255, 92, 0, 0.1)' : 'transparent'
              }}
            >
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center"
                style={{ backgroundColor: '#FF5C00' }}
              >
                <Building2 size={24} className="text-white" />
              </div>
              <div className="flex-1 text-left">
                <p>Bank Transfer</p>
                <p className="text-sm text-muted-foreground">Requires verification</p>
              </div>
            </button>
          </div>
        </div>

        {selectedMethod === 'transfer' && (
          <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
            <h3>Transfer Details</h3>

            <div>
              <p className="text-sm text-muted-foreground mb-1">Bank Name</p>
              <p>{bankName}</p>
            </div>

            <div>
              <p className="text-sm text-muted-foreground mb-1">Account Number</p>
              <div className="flex items-center gap-2">
                <p className="text-2xl" style={{ color: '#FF5C00' }}>{accountNumber}</p>
                <button
                  onClick={handleCopy}
                  className="p-2 rounded-lg bg-secondary"
                >
                  {copied ? <Check size={20} className="text-green-500" /> : <Copy size={20} />}
                </button>
              </div>
            </div>

            <div>
              <p className="text-sm text-muted-foreground mb-1">Amount</p>
              <p className="text-xl">₦{total.toLocaleString()}</p>
            </div>

            <div className="p-3 rounded-xl bg-accent/10 border border-accent">
              <p className="text-sm">
                After transfer, click "Verify Payment" below. A waiter will confirm your payment.
              </p>
            </div>
          </div>
        )}
      </div>

      {selectedMethod && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-card/95 backdrop-blur-sm border-t border-border">
          <button
            onClick={() => onPayment(selectedMethod)}
            className="w-full py-4 rounded-2xl text-white"
            style={{ backgroundColor: '#FF5C00' }}
          >
            {selectedMethod === 'card' ? 'Pay Now' : 'Verify Payment'}
          </button>
        </div>
      )}
    </div>
  );
}
