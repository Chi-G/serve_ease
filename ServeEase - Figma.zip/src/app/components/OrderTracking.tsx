import { useEffect, useState } from 'react';
import { Bell, CheckCircle2 } from 'lucide-react';
import type { Order } from '../App';

interface OrderTrackingProps {
  order: Order;
  onPlaceNewOrder: () => void;
  onAddMoreItems: () => void;
  onCallWaiter: () => void;
  onUpdateStatus: (status: Order['status']) => void;
}

export function OrderTracking({ order, onPlaceNewOrder, onAddMoreItems, onCallWaiter, onUpdateStatus }: OrderTrackingProps) {
  const [currentStatus, setCurrentStatus] = useState(order.status);
  const [timeRemaining, setTimeRemaining] = useState((order.estimatedTime || 0) * 60);
  const [showReadyFlash, setShowReadyFlash] = useState(false);

  useEffect(() => {
    if (currentStatus === 'in-kitchen' && timeRemaining > 0) {
      const interval = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            setCurrentStatus('ready');
            onUpdateStatus('ready');
            setShowReadyFlash(true);
            setTimeout(() => setShowReadyFlash(false), 2000);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [currentStatus, timeRemaining, onUpdateStatus]);

  const getStatusColor = () => {
    switch (currentStatus) {
      case 'pending':
        return '#FFA500';
      case 'paid':
        return '#4CAF50';
      case 'in-kitchen':
        return timeRemaining < 180 ? '#4CAF50' : '#FF5C00';
      case 'ready':
        return '#00FF00';
      default:
        return '#FF5C00';
    }
  };

  const getStatusText = () => {
    switch (currentStatus) {
      case 'pending':
        return 'Awaiting Payment Verification';
      case 'paid':
        return 'Payment Confirmed';
      case 'in-kitchen':
        return 'Being Prepared';
      case 'ready':
        return 'Order Ready!';
      default:
        return 'Processing';
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = order.estimatedTime ? ((order.estimatedTime * 60 - timeRemaining) / (order.estimatedTime * 60)) * 100 : 0;

  return (
    <div className="min-h-screen bg-background">
      {showReadyFlash && (
        <div className="fixed inset-0 z-[200] pointer-events-none animate-pulse">
          <div className="absolute inset-0" style={{ backgroundColor: '#00FF00', opacity: 0.3 }} />
        </div>
      )}

      <div className="sticky top-0 z-50 bg-card/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center justify-between px-4 py-4">
          <h1>Order Status</h1>
          <button
            onClick={onCallWaiter}
            className="p-3 rounded-full"
            style={{ backgroundColor: '#FF5C00' }}
          >
            <Bell size={20} className="text-white" />
          </button>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {currentStatus === 'ready' ? (
          <div
            className="min-h-[60vh] flex flex-col items-center justify-center text-center p-8 rounded-3xl"
            style={{ backgroundColor: 'rgba(0, 255, 0, 0.1)' }}
          >
            <div
              className="w-32 h-32 rounded-full flex items-center justify-center mb-6 animate-bounce"
              style={{ backgroundColor: '#00FF00' }}
            >
              <CheckCircle2 size={64} className="text-white" />
            </div>
            <h2 className="text-4xl mb-4" style={{ color: '#00FF00' }}>Order Ready!</h2>
            <p className="text-6xl mb-4" style={{ color: '#FF5C00' }}>{order.tokenNumber}</p>
            <p className="text-lg text-muted-foreground mb-8">Show this to the waiter</p>
            <div className="w-full max-w-xs space-y-3">
              <button
                onClick={onCallWaiter}
                className="w-full py-4 rounded-2xl text-white"
                style={{ backgroundColor: '#FF5C00' }}
              >
                Call Waiter
              </button>
              <button
                onClick={onPlaceNewOrder}
                className="w-full py-4 rounded-2xl bg-secondary"
              >
                Place a New Order
              </button>
              <button
                onClick={onAddMoreItems}
                className="w-full py-3 rounded-2xl border border-border text-sm"
              >
                Add More Items to This Order
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="bg-card rounded-2xl border border-border p-6 text-center">
              <div className="relative w-48 h-48 mx-auto mb-6">
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="96"
                    cy="96"
                    r="88"
                    fill="none"
                    stroke="#2A2A2A"
                    strokeWidth="8"
                  />
                  <circle
                    cx="96"
                    cy="96"
                    r="88"
                    fill="none"
                    stroke={getStatusColor()}
                    strokeWidth="8"
                    strokeDasharray={`${2 * Math.PI * 88}`}
                    strokeDashoffset={`${2 * Math.PI * 88 * (1 - (currentStatus === 'pending' ? 0.25 : currentStatus === 'paid' ? 0.5 : currentStatus === 'in-kitchen' ? progress / 100 : 1))}`}
                    className="transition-all duration-1000"
                    strokeLinecap="round"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div>
                    <p className="text-4xl mb-2" style={{ color: getStatusColor() }}>
                      {order.tokenNumber}
                    </p>
                    <p className="text-sm text-muted-foreground">{getStatusText()}</p>
                  </div>
                </div>
              </div>

              {currentStatus === 'in-kitchen' && timeRemaining > 0 && (
                <div className="mb-6">
                  <p className="text-sm text-muted-foreground mb-2">Estimated Wait Time</p>
                  <p className="text-3xl mb-3" style={{ color: getStatusColor() }}>
                    {formatTime(timeRemaining)}
                  </p>
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full transition-all duration-1000"
                      style={{
                        backgroundColor: getStatusColor(),
                        width: `${progress}%`
                      }}
                    />
                  </div>
                </div>
              )}

              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{
                      backgroundColor: ['pending', 'paid', 'in-kitchen', 'ready'].includes(currentStatus) ? '#4CAF50' : '#2A2A2A'
                    }}
                  />
                  <div className="flex-1 text-left">
                    <p className="text-sm">Order Placed</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{
                      backgroundColor: ['paid', 'in-kitchen', 'ready'].includes(currentStatus) ? '#4CAF50' : '#2A2A2A'
                    }}
                  />
                  <div className="flex-1 text-left">
                    <p className="text-sm">Payment Confirmed</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{
                      backgroundColor: ['in-kitchen', 'ready'].includes(currentStatus) ? getStatusColor() : '#2A2A2A'
                    }}
                  />
                  <div className="flex-1 text-left">
                    <p className="text-sm">In Kitchen</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{
                      backgroundColor: currentStatus === 'ready' ? '#00FF00' : '#2A2A2A'
                    }}
                  />
                  <div className="flex-1 text-left">
                    <p className="text-sm">Ready for Pickup</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-card rounded-2xl border border-border p-4">
              <h3 className="mb-3">Order Details</h3>
              <div className="space-y-2">
                {order.items.map((item, idx) => (
                  <div key={`${item.id}-${idx}`} className="flex justify-between text-sm">
                    <span className="flex items-center gap-2">
                      <span>{item.serviceType === 'eat-in' ? '🍽️' : '🥡'}</span>
                      <span>
                        {item.quantity}x {item.name}
                        <span className="text-muted-foreground text-xs ml-1">({item.customerName})</span>
                      </span>
                    </span>
                    <span>₦{(item.price * item.quantity).toLocaleString()}</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 pt-4 border-t border-border flex justify-between">
                <span>Total</span>
                <span style={{ color: '#FF5C00' }}>₦{order.total.toLocaleString()}</span>
              </div>
            </div>

            <div className="space-y-3">
              <button
                onClick={onAddMoreItems}
                className="w-full py-4 rounded-2xl bg-secondary"
              >
                Add More Items to This Order
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
