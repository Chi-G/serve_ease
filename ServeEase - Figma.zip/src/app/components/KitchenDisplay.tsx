import { useEffect, useState } from 'react';
import { Clock, Play, Check, Package } from 'lucide-react';
import type { Order } from '../App';

interface KitchenDisplayProps {
  orders: Order[];
  onUpdateOrder: (orderId: string, updates: Partial<Order>) => void;
}

export function KitchenDisplay({ orders, onUpdateOrder }: KitchenDisplayProps) {
  const [currentTime, setCurrentTime] = useState(Date.now());

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(Date.now());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const getElapsedMinutes = (timestamp: number) => {
    return Math.floor((currentTime - timestamp) / 60000);
  };

  const getOrderColor = (timestamp: number, status: string) => {
    if (status === 'ready') return '#4CAF50';
    const elapsed = getElapsedMinutes(timestamp);
    if (elapsed >= 15) return '#EF4444';
    if (elapsed >= 8) return '#FFA500';
    return '#FF5C00';
  };

  const getStatusBadge = (elapsed: number) => {
    if (elapsed >= 15) {
      return (
        <span className="px-2 py-1 rounded-full text-xs bg-red-500/20 text-red-400 animate-pulse">
          OVERDUE
        </span>
      );
    }
    return null;
  };

  const pendingOrders = orders.filter(o => o.status === 'pending');
  const inProgressOrders = orders.filter(o => o.status === 'in-kitchen');
  const readyOrders = orders.filter(o => o.status === 'ready');

  const OrderCard = ({ order }: { order: Order }) => {
    const elapsed = getElapsedMinutes(order.timestamp);
    const color = getOrderColor(order.timestamp, order.status);
    const isOverdue = elapsed >= 15 && order.status !== 'ready';

    return (
      <div
        className={`rounded-2xl border-2 p-4 space-y-3 transition-all ${isOverdue ? 'animate-pulse' : ''}`}
        style={{
          borderColor: color,
          boxShadow: isOverdue ? `0 0 20px ${color}40` : 'none'
        }}
      >
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <p className="text-2xl" style={{ color }}>{order.tokenNumber}</p>
              {getStatusBadge(elapsed)}
            </div>
            <p className="text-sm text-muted-foreground">Table {order.tableNumber}</p>
          </div>
          <div className="flex items-center gap-2 text-sm" style={{ color }}>
            <Clock size={16} />
            <span>{elapsed} min</span>
          </div>
        </div>

        <div className="space-y-2">
          {order.items.map((item, idx) => (
            <div
              key={idx}
              className="flex items-start justify-between p-2 rounded-lg bg-secondary"
            >
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-sm">
                    {item.quantity}x {item.name}
                  </p>
                  {item.serviceType === 'eat-in' ? (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400">
                      🍽️ PLATE
                    </span>
                  ) : (
                    <span className="text-xs px-2 py-0.5 rounded-full" style={{ backgroundColor: 'rgba(255, 92, 0, 0.2)', color: '#FF5C00' }}>
                      🥡 BAG
                    </span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  {item.customerName}
                </p>
              </div>
            </div>
          ))}
        </div>

        {order.status === 'pending' && (
          <button
            onClick={() => onUpdateOrder(order.id, { status: 'in-kitchen' })}
            className="w-full py-3 rounded-xl text-white transition-all flex items-center justify-center gap-2"
            style={{ backgroundColor: color }}
          >
            <Play size={18} />
            <span>Start Prep</span>
          </button>
        )}

        {order.status === 'in-kitchen' && (
          <button
            onClick={() => onUpdateOrder(order.id, { status: 'ready' })}
            className="w-full py-3 rounded-xl text-white transition-all flex items-center justify-center gap-2"
            style={{ backgroundColor: color }}
          >
            <Check size={18} />
            <span>Mark Ready</span>
          </button>
        )}

        {order.status === 'ready' && (
          <button
            className="w-full py-3 rounded-xl text-white transition-all flex items-center justify-center gap-2 opacity-50"
            style={{ backgroundColor: color }}
            disabled
          >
            <Package size={18} />
            <span>Awaiting Pickup</span>
          </button>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="mb-6">
        <h1 className="text-4xl mb-2">Kitchen Display System</h1>
        <p className="text-muted-foreground">
          {new Date().toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          })}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-xl">Pending</h2>
            <span className="px-3 py-1 rounded-full bg-yellow-500/20 text-yellow-400 text-sm">
              {pendingOrders.length}
            </span>
          </div>
          <div className="space-y-4">
            {pendingOrders.length === 0 ? (
              <div className="text-center text-muted-foreground py-12 bg-card rounded-2xl border border-border">
                No pending orders
              </div>
            ) : (
              pendingOrders.map(order => <OrderCard key={order.id} order={order} />)
            )}
          </div>
        </div>

        <div>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-xl">In Progress</h2>
            <span className="px-3 py-1 rounded-full text-sm" style={{ backgroundColor: 'rgba(255, 92, 0, 0.2)', color: '#FF5C00' }}>
              {inProgressOrders.length}
            </span>
          </div>
          <div className="space-y-4">
            {inProgressOrders.length === 0 ? (
              <div className="text-center text-muted-foreground py-12 bg-card rounded-2xl border border-border">
                No orders in progress
              </div>
            ) : (
              inProgressOrders
                .sort((a, b) => a.timestamp - b.timestamp)
                .map(order => <OrderCard key={order.id} order={order} />)
            )}
          </div>
        </div>

        <div>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-xl">Ready</h2>
            <span className="px-3 py-1 rounded-full bg-green-500/20 text-green-400 text-sm">
              {readyOrders.length}
            </span>
          </div>
          <div className="space-y-4">
            {readyOrders.length === 0 ? (
              <div className="text-center text-muted-foreground py-12 bg-card rounded-2xl border border-border">
                No orders ready
              </div>
            ) : (
              readyOrders.map(order => <OrderCard key={order.id} order={order} />)
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 bg-card rounded-2xl border border-border">
          <h3 className="text-sm mb-3">Time Indicators</h3>
          <div className="flex flex-wrap items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#FF5C00' }} />
              <span>0-7 min (Normal)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#FFA500' }} />
              <span>8-14 min (Caution)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full animate-pulse" style={{ backgroundColor: '#EF4444' }} />
              <span>15+ min (Overdue)</span>
            </div>
          </div>
        </div>

        <div className="p-4 bg-card rounded-2xl border border-border">
          <h3 className="text-sm mb-3">Service Type Badges</h3>
          <div className="flex flex-wrap items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <span className="text-xs px-2 py-1 rounded-full bg-blue-500/20 text-blue-400">
                🍽️ PLATE
              </span>
              <span>Eat-in service</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs px-2 py-1 rounded-full" style={{ backgroundColor: 'rgba(255, 92, 0, 0.2)', color: '#FF5C00' }}>
                🥡 BAG
              </span>
              <span>Take-away service</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
