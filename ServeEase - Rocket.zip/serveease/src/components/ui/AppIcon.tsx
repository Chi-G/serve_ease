import React from 'react';
import * as HeroIcons from '@heroicons/react/24/outline';
import * as HeroIconsSolid from '@heroicons/react/24/solid';

type IconName = keyof typeof HeroIcons | keyof typeof HeroIconsSolid;

interface IconProps {
  name: IconName;
  variant?: 'outline' | 'solid';
  size?: number;
  className?: string;
  onClick?: () => void;
  disabled?: boolean;
}

export default function Icon({
  name,
  variant = 'outline',
  size = 24,
  className = '',
  onClick,
  disabled = false,
}: IconProps) {
  const icons = variant === 'solid' ? HeroIconsSolid : HeroIcons;
  const IconComponent = icons[name as keyof typeof icons] as React.ElementType | undefined;

  if (!IconComponent) {
    return null;
  }

  return (
    <IconComponent
      width={size}
      height={size}
      className={`${disabled ? 'opacity-40 cursor-not-allowed' : ''} ${className}`}
      onClick={!disabled ? onClick : undefined}
      aria-hidden="true"
    />
  );
}