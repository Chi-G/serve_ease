import React from 'react';

interface AppLogoProps {
  src?: string;
  size?: number;
  iconName?: string;
  className?: string;
  onClick?: () => void;
}

export default function AppLogo({
  size = 64,
  className = '',
  onClick,
}: AppLogoProps) {
  return (
    <div
      onClick={onClick}
      className={`flex items-center justify-center rounded-xl flex-shrink-0 ${onClick ? 'cursor-pointer' : ''} ${className}`}
      style={{
        width: size,
        height: size,
        background: 'linear-gradient(135deg, #FF5C00 0%, #FF7A2F 100%)',
        boxShadow: '0 4px 12px rgba(255,92,0,0.35)',
      }}
      role={onClick ? 'button' : undefined}
      aria-label="ServeEase logo"
    >
      <svg
        width={size * 0.55}
        height={size * 0.55}
        viewBox="0 0 32 32"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        {/* Serving dome (cloche) */}
        <path
          d="M4 20 Q4 10 16 10 Q28 10 28 20 Z"
          fill="white"
          fillOpacity="0.95"
        />
        {/* Base plate */}
        <rect x="2" y="20" width="28" height="3" rx="1.5" fill="white" fillOpacity="0.7" />
        {/* Handle knob */}
        <circle cx="16" cy="10" r="2" fill="white" fillOpacity="0.6" />
      </svg>
    </div>
  );
}