'use client';

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { Users, Wifi, ChevronRight, Star } from 'lucide-react';
import AppLogo from '@/components/ui/AppLogo';

interface JoinTableFormData {
  guestName: string;
}

const ACTIVE_GUESTS = [
  { id: 'guest-001', name: 'Tunde', avatar: 'T', color: 'bg-blue-500' },
  { id: 'guest-002', name: 'Amaka', avatar: 'A', color: 'bg-purple-500' },
  { id: 'guest-003', name: 'Seun', avatar: 'S', color: 'bg-emerald-500' },
];

const TABLE_NUMBER = 12;
const RESTAURANT_NAME = "Forahia Kitchen";

export default function JoinTableContent() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm<JoinTableFormData>({ mode: 'onChange' });

  const guestNameValue = watch('guestName', '');

  const onSubmit = async (data: JoinTableFormData) => {
    setIsLoading(true);
    // BACKEND INTEGRATION: POST /api/sessions/join { tableId: TABLE_NUMBER, guestName: data.guestName }
    // Returns: { sessionToken, guestId, tableSessionId }
    await new Promise((r) => setTimeout(r, 900));
    if (typeof window !== 'undefined') {
      localStorage.setItem('serveease_guest_name', data.guestName);
      localStorage.setItem('serveease_table', String(TABLE_NUMBER));
    }
    router.push('/digital-show-glass-menu');
  };

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center overflow-hidden">
      {/* Blurred restaurant background */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1600&q=80')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          filter: 'blur(8px) brightness(0.45)',
          transform: 'scale(1.05)',
        }}
        aria-hidden="true"
      />

      {/* Dark overlay gradient */}
      <div
        className="absolute inset-0 z-0"
        style={{
          background:
            'linear-gradient(135deg, rgba(13,13,13,0.7) 0%, rgba(255,92,0,0.08) 100%)',
        }}
        aria-hidden="true"
      />

      {/* Content */}
      <div className="relative z-10 w-full max-w-sm mx-auto px-4 py-8 flex flex-col items-center gap-6">
        {/* Branding */}
        <div className="flex flex-col items-center gap-2 fade-in">
          <div className="flex items-center gap-2">
            <AppLogo size={40} />
            <span className="font-sans text-xl font-700 tracking-tight text-white">
              ServeEase
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-white/50">
            <Wifi size={12} />
            <span>Powered by Forahia</span>
          </div>
        </div>

        {/* Glassmorphism Card */}
        <div className="glass-card w-full rounded-2xl p-6 flex flex-col gap-5 fade-in">
          {/* Table badge */}
          <div className="flex items-center justify-between">
            <div className="flex flex-col gap-0.5">
              <p className="text-xs font-500 tracking-widest uppercase text-primary/80">
                {RESTAURANT_NAME}
              </p>
              <h1 className="text-2xl font-800 text-white leading-tight">
                Table {TABLE_NUMBER}
              </h1>
            </div>
            <div
              className="flex items-center justify-center w-14 h-14 rounded-xl"
              style={{ background: 'rgba(255,92,0,0.15)', border: '1px solid rgba(255,92,0,0.3)' }}
            >
              <span className="text-2xl" role="img" aria-label="table">🍽️</span>
            </div>
          </div>

          {/* Active guests */}
          <div
            className="flex items-center gap-3 p-3 rounded-xl"
            style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}
          >
            <div className="flex -space-x-2">
              {ACTIVE_GUESTS.map((g) => (
                <div
                  key={g.id}
                  className={`w-8 h-8 rounded-full ${g.color} flex items-center justify-center text-white text-xs font-700 ring-2 ring-black/40`}
                  title={g.name}
                >
                  {g.avatar}
                </div>
              ))}
            </div>
            <div className="flex flex-col gap-0">
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
                <p className="text-xs font-600 text-white/90">
                  {ACTIVE_GUESTS.length} guests active
                </p>
              </div>
              <p className="text-2xs text-muted-foreground">
                {ACTIVE_GUESTS.map((g) => g.name).join(', ')} already browsing
              </p>
            </div>
          </div>

          {/* Name form */}
          <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="guestName"
                className="text-sm font-600 text-white/80"
              >
                What is your name?
              </label>
              <p className="text-2xs text-muted-foreground">
                So we can personalize your order at this table
              </p>
              <input
                id="guestName"
                type="text"
                autoComplete="given-name"
                placeholder="e.g. Chijindu"
                className={`w-full px-4 py-3.5 rounded-xl text-base font-600 text-white placeholder:text-white/25 outline-none transition-all duration-200 focus:ring-2 focus:ring-primary/60 ${
                  errors.guestName
                    ? 'ring-2 ring-danger/60' :'ring-1 ring-white/10'
                }`}
                style={{ background: 'rgba(255,255,255,0.07)' }}
                {...register('guestName', {
                  required: 'Please enter your name to continue',
                  minLength: {
                    value: 2,
                    message: 'Name must be at least 2 characters',
                  },
                  maxLength: {
                    value: 30,
                    message: 'Name is too long',
                  },
                  pattern: {
                    value: /^[a-zA-ZÀ-ÿ\s'-]+$/,
                    message: 'Name can only contain letters',
                  },
                })}
              />
              {errors.guestName && (
                <p className="text-xs text-danger font-500 flex items-center gap-1">
                  <span>⚠</span> {errors.guestName.message}
                </p>
              )}
            </div>

            {/* CTA */}
            <button
              type="submit"
              disabled={isLoading || !guestNameValue.trim()}
              className="w-full flex items-center justify-center gap-2 py-4 px-6 rounded-xl text-base font-700 text-white transition-all duration-150 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed orange-glow"
              style={{
                background: isLoading
                  ? 'rgba(255,92,0,0.6)'
                  : 'linear-gradient(135deg, #FF5C00 0%, #FF7A2F 100%)',
              }}
            >
              {isLoading ? (
                <>
                  <svg
                    className="animate-spin w-5 h-5 text-white"
                    fill="none"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8v8z"
                    />
                  </svg>
                  <span>Joining Table...</span>
                </>
              ) : (
                <>
                  <span>See Menu</span>
                  <ChevronRight size={18} />
                </>
              )}
            </button>
          </form>
        </div>

        {/* Footer trust signals */}
        <div className="flex items-center gap-4 text-2xs text-white/30 fade-in">
          <div className="flex items-center gap-1">
            <Star size={10} className="text-primary/60" />
            <span>4.9 rated</span>
          </div>
          <span>•</span>
          <div className="flex items-center gap-1">
            <Users size={10} />
            <span>12 orders today</span>
          </div>
          <span>•</span>
          <span>Secured by Forahia</span>
        </div>
      </div>
    </div>
  );
}