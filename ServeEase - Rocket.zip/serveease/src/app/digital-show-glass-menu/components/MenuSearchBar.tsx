'use client';

import React from 'react';
import { Search, X } from 'lucide-react';

interface MenuSearchBarProps {
  value: string;
  onChange: (v: string) => void;
}

export default function MenuSearchBar({ value, onChange }: MenuSearchBarProps) {
  return (
    <div
      className="flex items-center gap-3 px-4 py-3 rounded-xl"
      style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)' }}
    >
      <Search size={16} className="text-muted-foreground flex-shrink-0" />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Search food, drinks..."
        className="flex-1 bg-transparent text-sm text-white placeholder:text-muted-foreground outline-none"
        aria-label="Search menu items"
      />
      {value && (
        <button
          onClick={() => onChange('')}
          className="flex-shrink-0 p-0.5 rounded-full transition-colors hover:bg-white/10"
          aria-label="Clear search"
        >
          <X size={14} className="text-muted-foreground" />
        </button>
      )}
    </div>
  );
}