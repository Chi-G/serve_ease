export type StockStatus = 'fresh' | 'limited' | 'sold-out';
export type ServiceStyle = 'eat-in' | 'takeaway';

export interface PortionOption {
  id: string;
  label: string;
  price: number;
}

export interface MenuItem {
  id: string;
  name: string;
  category: string;
  description: string;
  image: string;
  imageAlt: string;
  price: number;
  portions: PortionOption[];
  status: StockStatus;
  calories: number;
  prepTime: number;
  isPopular: boolean;
  upsells: string[];
}

export interface Category {
  id: string;
  label: string;
  emoji: string;
}

export const CATEGORIES: Category[] = [
{ id: 'cat-all', label: 'All', emoji: '🍴' },
{ id: 'cat-meals', label: 'Meals', emoji: '🥘' },
{ id: 'cat-proteins', label: 'Proteins', emoji: '🍗' },
{ id: 'cat-sides', label: 'Sides', emoji: '🥗' },
{ id: 'cat-drinks', label: 'Drinks', emoji: '🥤' },
{ id: 'cat-soups', label: 'Soups', emoji: '🍲' },
{ id: 'cat-snacks', label: 'Snacks', emoji: '🧆' }];


export const MENU_ITEMS: MenuItem[] = [
{
  id: 'item-001',
  name: 'Party Jollof Rice',
  category: 'Meals',
  description: 'Smoky, perfectly spiced jollof rice cooked over firewood. The real deal.',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1ec45c5a5-1772880148244.png",
  imageAlt: 'Steaming plate of orange-red jollof rice with tomato sauce and seasoning',
  price: 3500,
  portions: [
  { id: 'p-001-sm', label: 'Small', price: 2200 },
  { id: 'p-001-md', label: 'Medium', price: 3500 },
  { id: 'p-001-lg', label: 'Large', price: 5000 }],

  status: 'fresh',
  calories: 480,
  prepTime: 10,
  isPopular: true,
  upsells: ['item-004', 'item-005', 'item-006']
},
{
  id: 'item-002',
  name: 'Fried Rice & Plantain',
  category: 'Meals',
  description: 'Fluffy fried rice loaded with mixed vegetables, served with sweet fried plantain.',
  image: "https://images.unsplash.com/photo-1733024458793-e6e1af46ff1e",
  imageAlt: 'Yellow fried rice with colorful mixed vegetables and golden fried plantain slices',
  price: 3200,
  portions: [
  { id: 'p-002-sm', label: 'Small', price: 2000 },
  { id: 'p-002-md', label: 'Medium', price: 3200 },
  { id: 'p-002-lg', label: 'Large', price: 4800 }],

  status: 'fresh',
  calories: 520,
  prepTime: 12,
  isPopular: true,
  upsells: ['item-004', 'item-005', 'item-007']
},
{
  id: 'item-003',
  name: 'Egusi Soup & Pounded Yam',
  category: 'Soups',
  description: 'Thick, rich egusi soup with assorted meat and stockfish, paired with smooth pounded yam.',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_147dd8d5a-1772058275411.png",
  imageAlt: 'Rich brown egusi soup with chunks of meat in a clay pot beside white pounded yam',
  price: 4800,
  portions: [
  { id: 'p-003-sm', label: 'Small', price: 3200 },
  { id: 'p-003-md', label: 'Medium', price: 4800 },
  { id: 'p-003-lg', label: 'Large', price: 6500 }],

  status: 'limited',
  calories: 680,
  prepTime: 15,
  isPopular: false,
  upsells: ['item-008', 'item-009']
},
{
  id: 'item-004',
  name: 'Grilled Chicken',
  category: 'Proteins',
  description: 'Half chicken marinated in suya spice, grilled to perfection. Crispy outside, juicy inside.',
  image: "https://images.unsplash.com/photo-1617636424188-78e2825e8b87",
  imageAlt: 'Golden-brown grilled chicken half with char marks and fresh herb garnish on a wooden board',
  price: 3800,
  portions: [
  { id: 'p-004-qtr', label: 'Quarter', price: 2200 },
  { id: 'p-004-half', label: 'Half', price: 3800 },
  { id: 'p-004-full', label: 'Full', price: 7200 }],

  status: 'fresh',
  calories: 420,
  prepTime: 8,
  isPopular: true,
  upsells: ['item-001', 'item-002', 'item-010']
},
{
  id: 'item-005',
  name: 'Suya Beef Skewers',
  category: 'Proteins',
  description: 'Street-style suya with authentic yaji spice blend. Served with sliced onions and tomatoes.',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1c179f4d2-1772058276389.png",
  imageAlt: 'Spiced beef skewers on wooden sticks with red yaji powder coating and sliced onions',
  price: 2800,
  portions: [
  { id: 'p-005-3', label: '3 Sticks', price: 1800 },
  { id: 'p-005-6', label: '6 Sticks', price: 2800 },
  { id: 'p-005-12', label: '12 Sticks', price: 5200 }],

  status: 'fresh',
  calories: 310,
  prepTime: 6,
  isPopular: true,
  upsells: ['item-010', 'item-011']
},
{
  id: 'item-006',
  name: 'Peppered Goat Meat',
  category: 'Proteins',
  description: 'Tender goat meat slow-cooked in a rich pepper sauce. A Nigerian classic.',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1dde845ad-1777532359480.png",
  imageAlt: 'Dark brown peppered goat meat in thick red pepper sauce with scotch bonnet peppers',
  price: 4200,
  portions: [
  { id: 'p-006-sm', label: 'Small', price: 2800 },
  { id: 'p-006-md', label: 'Medium', price: 4200 },
  { id: 'p-006-lg', label: 'Large', price: 6800 }],

  status: 'sold-out',
  calories: 390,
  prepTime: 10,
  isPopular: false,
  upsells: ['item-004', 'item-005']
},
{
  id: 'item-007',
  name: 'Fried Plantain (Dodo)',
  category: 'Sides',
  description: 'Sweet, ripe plantain fried golden. The perfect companion to any meal.',
  image: "https://images.unsplash.com/photo-1627383574427-b258289835c8",
  imageAlt: 'Golden-yellow fried plantain slices arranged on a white plate',
  price: 800,
  portions: [
  { id: 'p-007-sm', label: 'Small', price: 500 },
  { id: 'p-007-md', label: 'Medium', price: 800 },
  { id: 'p-007-lg', label: 'Large', price: 1200 }],

  status: 'fresh',
  calories: 180,
  prepTime: 5,
  isPopular: false,
  upsells: ['item-001', 'item-002']
},
{
  id: 'item-008',
  name: 'Coleslaw',
  category: 'Sides',
  description: 'Creamy, freshly made coleslaw with carrots and cabbage. Light and refreshing.',
  image: "https://images.unsplash.com/photo-1630409350018-0e06ea178b92",
  imageAlt: 'Creamy white coleslaw with shredded carrots and green cabbage in a small bowl',
  price: 600,
  portions: [
  { id: 'p-008-sm', label: 'Small', price: 400 },
  { id: 'p-008-md', label: 'Medium', price: 600 }],

  status: 'fresh',
  calories: 120,
  prepTime: 2,
  isPopular: false,
  upsells: ['item-004', 'item-002']
},
{
  id: 'item-009',
  name: 'Moi Moi',
  category: 'Sides',
  description: 'Steamed bean pudding with boiled egg and fish inside. A comforting Nigerian staple.',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_10365215c-1767179593616.png",
  imageAlt: 'Brown steamed moi moi wrapped in banana leaf with egg visible inside on a plate',
  price: 700,
  portions: [
  { id: 'p-009-one', label: '1 Wrap', price: 700 },
  { id: 'p-009-two', label: '2 Wraps', price: 1300 }],

  status: 'limited',
  calories: 210,
  prepTime: 3,
  isPopular: false,
  upsells: ['item-001', 'item-003']
},
{
  id: 'item-010',
  name: 'Chapman',
  category: 'Drinks',
  description: 'Nigeria\'s favourite mocktail. Fanta, Grenadine, cucumber, and a slice of orange.',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_174e5ed13-1773153269845.png",
  imageAlt: 'Red Chapman cocktail in a tall glass with orange slice and cucumber garnish',
  price: 1200,
  portions: [
  { id: 'p-010-reg', label: 'Regular', price: 1200 },
  { id: 'p-010-jug', label: 'Jug (4 ppl)', price: 4000 }],

  status: 'fresh',
  calories: 150,
  prepTime: 3,
  isPopular: true,
  upsells: ['item-011']
},
{
  id: 'item-011',
  name: 'Zobo Hibiscus',
  category: 'Drinks',
  description: 'Chilled zobo made from dried hibiscus petals with ginger and pineapple.',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_11fd70fa6-1771845362520.png",
  imageAlt: 'Deep red hibiscus drink in a glass with ice cubes and fresh mint leaves',
  price: 800,
  portions: [
  { id: 'p-011-reg', label: 'Regular', price: 800 },
  { id: 'p-011-lrg', label: 'Large', price: 1400 }],

  status: 'fresh',
  calories: 90,
  prepTime: 2,
  isPopular: false,
  upsells: ['item-010']
},
{
  id: 'item-012',
  name: 'Puff Puff',
  category: 'Snacks',
  description: 'Hot, airy deep-fried dough balls dusted with sugar. Best served fresh.',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1a35ddf75-1773153349829.png",
  imageAlt: 'Golden brown round puff puff snacks dusted with powdered sugar on brown paper',
  price: 600,
  portions: [
  { id: 'p-012-5', label: '5 Pieces', price: 600 },
  { id: 'p-012-10', label: '10 Pieces', price: 1100 }],

  status: 'fresh',
  calories: 240,
  prepTime: 4,
  isPopular: false,
  upsells: ['item-010', 'item-011']
}];