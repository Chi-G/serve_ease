'use client';

import React from 'react';
import AppImage from '@/components/ui/AppImage';
import type { MenuItem } from './menuData';
import { Flame, Clock } from 'lucide-react';

interface MenuItemCardProps {
  item: MenuItem;
  onClick: () => void;
}

function StockBadge({ status }: { status: MenuItem['status'] }) {
  if (status === 'fresh') {
    return (
      <div
        className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full text-2xs font-700"
        style={{ background: 'rgba(34,197,94,0.85)', color: '#fff' }}
      >
        <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse inline-block" />
        Fresh
      </div>
    );
  }
  if (status === 'limited') {
    return (
      <div
        className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full text-2xs font-700"
        style={{ background: 'rgba(245,158,11,0.9)', color: '#fff' }}
      >
        <span className="w-1.5 h-1.5 rounded-full bg-white inline-block" />
        Limited
      </div>
    );
  }
  return (
    <div
      className="absolute inset-0 rounded-t-xl flex items-center justify-center"
      style={{ background: 'rgba(0,0,0,0.65)' }}
    >
      <div
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-700"
        style={{ background: 'rgba(239,68,68,0.85)', color: '#fff' }}
      >
        <span>Sold Out</span>
      </div>
    </div>
  );
}

export default function MenuItemCard({ item, onClick }: MenuItemCardProps) {
  const isSoldOut = item.status === 'sold-out';

  return (
    <button
      onClick={onClick}
      className={`relative flex flex-col rounded-2xl overflow-hidden text-left transition-all duration-200 active:scale-97 ${
        isSoldOut ? 'opacity-70' : 'hover:scale-[1.02]'
      }`}
      style={{ background: 'var(--card)', border: '1px solid rgba(255,255,255,0.07)' }}
      aria-label={`${item.name} — ₦${item.price.toLocaleString()}`}
    >
      {/* Image */}
      <div className="relative w-full aspect-square overflow-hidden">
        <AppImage
          src={item.image}
          alt={item.imageAlt}
          fill
          className="object-cover"
          sizes="(max-width: 768px) 50vw, 25vw"
        />
        {/* Gradient overlay */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'linear-gradient(to bottom, transparent 50%, rgba(0,0,0,0.7) 100%)',
          }}
          aria-hidden="true"
        />
        {/* Stock badge */}
        <StockBadge status={item.status} />
        {/* Price tag */}
        {!isSoldOut && (
          <div
            className="absolute bottom-2 right-2 px-2 py-1 rounded-lg text-xs font-800 text-white tabular-nums"
            style={{ background: 'rgba(255,92,0,0.9)' }}
          >
            ₦{item.price.toLocaleString()}
          </div>
        )}
        {/* Popular badge */}
        {item.isPopular && (
          <div
            className="absolute top-2 right-2 w-6 h-6 rounded-full flex items-center justify-center"
            style={{ background: 'rgba(255,92,0,0.85)' }}
            title="Popular"
          >
            <Flame size={12} className="text-white" />
          </div>
        )}
      </div>

      {/* Info */}
      <div className="p-3 flex flex-col gap-1">
        <p className="text-sm font-700 text-white leading-tight line-clamp-1">{item.name}</p>
        <p className="text-2xs text-muted-foreground line-clamp-2 leading-relaxed">
          {item.description}
        </p>
        <div className="flex items-center gap-2 mt-1">
          <div className="flex items-center gap-0.5 text-2xs text-muted-foreground">
            <Clock size={10} />
            <span>{item.prepTime}m</span>
          </div>
          <span className="text-2xs text-muted-foreground">·</span>
          <span className="text-2xs text-muted-foreground">{item.calories} cal</span>
        </div>
      </div>
    </button>
  );
}