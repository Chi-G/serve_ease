'use client';

import React, { useState, useImperativeHandle, forwardRef, useEffect } from 'react';
import { ShoppingCart, ChevronRight } from 'lucide-react';
import { useRouter } from 'next/navigation';
import type { CartItem } from './MenuScreenWrapper';
import CartDrawer from './CartDrawer';

interface CartFABProps {
  itemCount: number;
  totalValue: number;
  cartItems: CartItem[];
}

export interface CartFABHandle {
  triggerBounce: () => void;
}

const CartFAB = forwardRef<CartFABHandle, CartFABProps>(
  ({ itemCount, totalValue, cartItems }, ref) => {
    const router = useRouter();
    const [bouncing, setBouncing] = useState(false);
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);

    useImperativeHandle(ref, () => ({
      triggerBounce() {
        setBouncing(true);
        setTimeout(() => setBouncing(false), 500);
      },
    }));

    const handleCheckout = () => {
      // BACKEND INTEGRATION: POST /api/cart/save { tableId: 12, guestName, items: cartItems }
      if (typeof window !== 'undefined') {
        localStorage.setItem('serveease_cart', JSON.stringify(cartItems));
      }
      router.push('/checkout-hub');
    };

    if (itemCount === 0) return null;

    return (
      <>
        <div className="fixed bottom-6 left-4 right-4 z-40 max-w-lg mx-auto">
          <button
            onClick={() => setIsDrawerOpen(true)}
            className={`w-full flex items-center justify-between px-5 py-4 rounded-2xl text-white transition-all duration-200 active:scale-95 orange-glow ${
              bouncing ? 'cart-bounce' : ''
            }`}
            style={{
              background: 'linear-gradient(135deg, #FF5C00 0%, #FF7A2F 100%)',
            }}
            aria-label={`View cart — ${itemCount} items — ₦${totalValue.toLocaleString()}`}
          >
            <div className="flex items-center gap-3">
              <div className="relative">
                <ShoppingCart size={20} className="text-white" />
                <span
                  className="absolute -top-2 -right-2 w-5 h-5 rounded-full flex items-center justify-center text-2xs font-800 text-primary"
                  style={{ background: '#fff' }}
                >
                  {itemCount}
                </span>
              </div>
              <span className="text-sm font-700">View Cart</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-800 tabular-nums">
                ₦{totalValue.toLocaleString()}
              </span>
              <ChevronRight size={16} />
            </div>
          </button>
        </div>

        <CartDrawer
          isOpen={isDrawerOpen}
          onClose={() => setIsDrawerOpen(false)}
          cartItems={cartItems}
          onCheckout={handleCheckout}
          totalValue={totalValue}
        />
      </>
    );
  }
);

CartFAB.displayName = 'CartFAB';
export default CartFAB;