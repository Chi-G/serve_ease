import React from 'react';

export default function MenuItemSkeleton() {
  return (
    <div
      className="flex flex-col rounded-2xl overflow-hidden"
      style={{ background: 'var(--card)', border: '1px solid rgba(255,255,255,0.07)' }}
    >
      <div className="w-full aspect-square shimmer" style={{ background: 'var(--muted)' }} />
      <div className="p-3 flex flex-col gap-2">
        <div className="h-4 rounded-md shimmer" style={{ background: 'var(--muted)', width: '75%' }} />
        <div className="h-3 rounded-md shimmer" style={{ background: 'var(--muted)', width: '90%' }} />
        <div className="h-3 rounded-md shimmer" style={{ background: 'var(--muted)', width: '55%' }} />
      </div>
    </div>
  );
}