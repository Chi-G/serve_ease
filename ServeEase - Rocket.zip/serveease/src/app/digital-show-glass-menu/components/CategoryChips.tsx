'use client';

import React, { useRef } from 'react';
import type { Category } from './menuData';

interface CategoryChipsProps {
  categories: Category[];
  activeCategory: string;
  onSelect: (id: string) => void;
}

export default function CategoryChips({ categories, activeCategory, onSelect }: CategoryChipsProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  return (
    <div className="relative">
      <div
        ref={scrollRef}
        className="flex items-center gap-2 px-4 py-3 overflow-x-auto scrollbar-hide"
      >
        {categories.map((cat) => {
          const isActive = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => onSelect(cat.id)}
              className="flex-shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-600 transition-all duration-200 active:scale-95"
              style={
                isActive
                  ? {
                      background: 'linear-gradient(135deg, #FF5C00, #FF7A2F)',
                      color: '#FFFFFF',
                      boxShadow: '0 4px 12px rgba(255,92,0,0.35)',
                    }
                  : {
                      background: 'rgba(255,255,255,0.06)',
                      color: 'rgba(255,255,255,0.6)',
                      border: '1px solid rgba(255,255,255,0.08)',
                    }
              }
            >
              <span role="img" aria-label={cat.label}>{cat.emoji}</span>
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>
      {/* Right fade */}
      <div
        className="absolute right-0 top-0 bottom-0 w-8 pointer-events-none"
        style={{ background: 'linear-gradient(to left, var(--background), transparent)' }}
        aria-hidden="true"
      />
    </div>
  );
}