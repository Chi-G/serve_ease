'use client';

import React from 'react';
import type { MenuItem } from './menuData';
import MenuItemCard from './MenuItemCard';
import MenuItemSkeleton from './MenuItemSkeleton';

interface MenuGridProps {
  items: MenuItem[];
  isLoading: boolean;
  onItemClick: (item: MenuItem) => void;
}

const SKELETON_IDS = ['sk-1','sk-2','sk-3','sk-4','sk-5','sk-6','sk-7','sk-8'];

export default function MenuGrid({ items, isLoading, onItemClick }: MenuGridProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-2 gap-3 pt-2">
        {SKELETON_IDS.map((id) => (
          <MenuItemSkeleton key={id} />
        ))}
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-4">
        <div
          className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl"
          style={{ background: 'rgba(255,255,255,0.05)' }}
        >
          🔍
        </div>
        <div className="text-center">
          <p className="text-base font-700 text-white/70">No items found</p>
          <p className="text-sm text-muted-foreground mt-1">
            Try a different category or search term
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3 pt-2 fade-in">
      {items.map((item) => (
        <MenuItemCard key={item.id} item={item} onClick={() => onItemClick(item)} />
      ))}
    </div>
  );
}