'use client';

import React, { useState } from 'react';
import { X, Users } from 'lucide-react';

interface GroupOrderBannerProps {
  guestName: string;
}

const OTHER_GUESTS_ORDERING = [
  { id: 'banner-guest-001', name: 'Tunde', item: 'Fried Rice & Plantain' },
  { id: 'banner-guest-002', name: 'Amaka', item: 'Chapman' },
];

export default function GroupOrderBanner({ guestName }: GroupOrderBannerProps) {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div
      className="mx-4 mb-1 px-3 py-2.5 rounded-xl flex items-center gap-2 fade-in"
      style={{ background: 'rgba(255,92,0,0.08)', border: '1px solid rgba(255,92,0,0.18)' }}
    >
      <Users size={13} className="text-primary flex-shrink-0" />
      <p className="flex-1 text-2xs text-white/70 leading-relaxed">
        <span className="font-600 text-white/90">{OTHER_GUESTS_ORDERING[0].name}</span>
        {' '}is ordering {OTHER_GUESTS_ORDERING[0].item} ·{' '}
        <span className="font-600 text-white/90">{OTHER_GUESTS_ORDERING[1].name}</span>
        {' '}added {OTHER_GUESTS_ORDERING[1].item}
      </p>
      <button
        onClick={() => setDismissed(true)}
        className="flex-shrink-0 p-0.5 rounded-full hover:bg-white/10 transition-colors"
        aria-label="Dismiss group order banner"
      >
        <X size={12} className="text-muted-foreground" />
      </button>
    </div>
  );
}