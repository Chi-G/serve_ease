'use client';

import React, { useState, useEffect } from 'react';
import { X, Minus, Plus, ShoppingBag, UtensilsCrossed } from 'lucide-react';
import AppImage from '@/components/ui/AppImage';
import type { MenuItem } from './menuData';
import { MENU_ITEMS } from './menuData';
import type { CartItem } from './MenuScreenWrapper';

interface ProductDetailSheetProps {
  item: MenuItem;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (item: CartItem) => void;
  allItems: MenuItem[];
}

type ServiceStyle = 'eat-in' | 'takeaway';

export default function ProductDetailSheet({
  item,
  isOpen,
  onClose,
  onAddToCart,
}: ProductDetailSheetProps) {
  const [selectedPortionId, setSelectedPortionId] = useState(item.portions[1]?.id ?? item.portions[0].id);
  const [serviceStyle, setServiceStyle] = useState<ServiceStyle>('eat-in');
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    setSelectedPortionId(item.portions[1]?.id ?? item.portions[0].id);
    setQuantity(1);
    setServiceStyle('eat-in');
  }, [item]);

  const selectedPortion = item.portions.find((p) => p.id === selectedPortionId) ?? item.portions[0];
  const totalPrice = selectedPortion.price * quantity;

  const upsellItems = MENU_ITEMS.filter(
    (m) => item.upsells.includes(m.id) && m.status !== 'sold-out'
  ).slice(0, 3);

  const handleAdd = () => {
    const cartItem: CartItem = {
      cartId: `cart-${item.id}-${selectedPortionId}-${serviceStyle}-${Date.now()}`,
      itemId: item.id,
      name: item.name,
      portionLabel: selectedPortion.label,
      portionPrice: selectedPortion.price,
      quantity,
      serviceStyle,
      image: item.image,
      imageAlt: item.imageAlt,
    };
    onAddToCart(cartItem);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Sheet */}
      <div
        className="fixed bottom-0 left-0 right-0 z-50 max-w-lg mx-auto rounded-t-3xl overflow-hidden slide-up"
        style={{ background: 'var(--secondary)', maxHeight: '92vh' }}
        role="dialog"
        aria-modal="true"
        aria-label={item.name}
      >
        {/* Drag handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full" style={{ background: 'rgba(255,255,255,0.2)' }} />
        </div>

        <div className="overflow-y-auto" style={{ maxHeight: 'calc(92vh - 16px)' }}>
          {/* Hero image */}
          <div className="relative w-full h-52 overflow-hidden">
            <AppImage
              src={item.image}
              alt={item.imageAlt}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 512px"
            />
            <div
              className="absolute inset-0"
              style={{ background: 'linear-gradient(to bottom, transparent 40%, rgba(26,26,26,1) 100%)' }}
              aria-hidden="true"
            />
            <button
              onClick={onClose}
              className="absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center transition-all active:scale-90"
              style={{ background: 'rgba(0,0,0,0.6)' }}
              aria-label="Close"
            >
              <X size={16} className="text-white" />
            </button>
          </div>

          <div className="px-5 pb-6 flex flex-col gap-5">
            {/* Title + description */}
            <div className="flex flex-col gap-1.5">
              <h2 className="text-xl font-800 text-white">{item.name}</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
              <div className="flex items-center gap-3 mt-1">
                <span className="text-xs text-muted-foreground">{item.calories} cal</span>
                <span className="text-xs text-muted-foreground">·</span>
                <span className="text-xs text-muted-foreground">~{item.prepTime} min prep</span>
              </div>
            </div>

            {/* Service style toggle */}
            <div className="flex flex-col gap-2">
              <p className="text-sm font-600 text-white/80">Service Style</p>
              <div
                className="flex rounded-xl p-1 gap-1"
                style={{ background: 'rgba(255,255,255,0.05)' }}
                role="group"
                aria-label="Service style"
              >
                {(['eat-in', 'takeaway'] as ServiceStyle[]).map((style) => {
                  const isActive = serviceStyle === style;
                  return (
                    <button
                      key={`style-${style}`}
                      onClick={() => setServiceStyle(style)}
                      className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-700 transition-all duration-200 active:scale-95"
                      style={
                        isActive
                          ? {
                              background: 'linear-gradient(135deg, #FF5C00, #FF7A2F)',
                              color: '#fff',
                              boxShadow: '0 4px 12px rgba(255,92,0,0.3)',
                            }
                          : { color: 'rgba(255,255,255,0.5)' }
                      }
                    >
                      {style === 'eat-in' ? (
                        <>
                          <UtensilsCrossed size={15} />
                          <span>Eat-in</span>
                        </>
                      ) : (
                        <>
                          <ShoppingBag size={15} />
                          <span>Takeaway</span>
                        </>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Portion selector */}
            <div className="flex flex-col gap-2">
              <p className="text-sm font-600 text-white/80">Portion Size</p>
              <div className="flex flex-col gap-2">
                {item.portions.map((portion) => {
                  const isSelected = selectedPortionId === portion.id;
                  return (
                    <button
                      key={portion.id}
                      onClick={() => setSelectedPortionId(portion.id)}
                      className="flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-150 active:scale-98"
                      style={
                        isSelected
                          ? {
                              background: 'rgba(255,92,0,0.1)',
                              border: '1.5px solid rgba(255,92,0,0.5)',
                            }
                          : {
                              background: 'rgba(255,255,255,0.04)',
                              border: '1.5px solid rgba(255,255,255,0.08)',
                            }
                      }
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="w-4 h-4 rounded-full flex items-center justify-center"
                          style={{
                            border: isSelected
                              ? '4px solid #FF5C00' :'2px solid rgba(255,255,255,0.25)',
                          }}
                        />
                        <span
                          className={`text-sm font-600 ${isSelected ? 'text-white' : 'text-white/60'}`}
                        >
                          {portion.label}
                        </span>
                      </div>
                      <span
                        className={`text-sm font-700 tabular-nums ${
                          isSelected ? 'text-primary' : 'text-white/50'
                        }`}
                      >
                        ₦{portion.price.toLocaleString()}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quantity stepper */}
            <div className="flex items-center justify-between">
              <p className="text-sm font-600 text-white/80">Quantity</p>
              <div
                className="flex items-center gap-4 px-4 py-2 rounded-xl"
                style={{ background: 'rgba(255,255,255,0.06)' }}
              >
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  disabled={quantity <= 1}
                  className="w-7 h-7 rounded-lg flex items-center justify-center transition-all active:scale-90 disabled:opacity-30"
                  style={{ background: 'rgba(255,255,255,0.1)' }}
                  aria-label="Decrease quantity"
                >
                  <Minus size={14} className="text-white" />
                </button>
                <span className="text-base font-800 text-white tabular-nums w-5 text-center">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity((q) => Math.min(10, q + 1))}
                  disabled={quantity >= 10}
                  className="w-7 h-7 rounded-lg flex items-center justify-center transition-all active:scale-90 disabled:opacity-30"
                  style={{ background: 'rgba(255,92,0,0.3)', border: '1px solid rgba(255,92,0,0.5)' }}
                  aria-label="Increase quantity"
                >
                  <Plus size={14} className="text-primary" />
                </button>
              </div>
            </div>

            {/* AI Upsell */}
            {upsellItems.length > 0 && (
              <div className="flex flex-col gap-2.5">
                <p className="text-sm font-600 text-white/80">
                  🤖 Add a protein?
                </p>
                <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
                  {upsellItems.map((u) => (
                    <div
                      key={`upsell-${u.id}`}
                      className="flex-shrink-0 flex items-center gap-2 px-3 py-2 rounded-xl"
                      style={{
                        background: 'rgba(255,255,255,0.05)',
                        border: '1px solid rgba(255,255,255,0.08)',
                        minWidth: 140,
                      }}
                    >
                      <div className="w-10 h-10 rounded-lg overflow-hidden flex-shrink-0">
                        <AppImage
                          src={u.image}
                          alt={u.imageAlt}
                          width={40}
                          height={40}
                          className="object-cover w-full h-full"
                        />
                      </div>
                      <div className="flex flex-col gap-0.5 min-w-0">
                        <p className="text-xs font-700 text-white line-clamp-1">{u.name}</p>
                        <p className="text-2xs text-primary font-600 tabular-nums">
                          +₦{u.portions[0].price.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* CTA */}
            <button
              onClick={handleAdd}
              className="w-full flex items-center justify-between px-5 py-4 rounded-xl text-base font-700 text-white transition-all duration-150 active:scale-95 orange-glow"
              style={{
                background: 'linear-gradient(135deg, #FF5C00 0%, #FF7A2F 100%)',
              }}
            >
              <span>Add to Cart</span>
              <span className="tabular-nums">₦{totalPrice.toLocaleString()}</span>
            </button>
          </div>
        </div>
      </div>
    </>
  );
}