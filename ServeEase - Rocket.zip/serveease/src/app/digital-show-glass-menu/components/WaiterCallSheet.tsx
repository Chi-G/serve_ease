'use client';

import React, { useState } from 'react';
import { X, Bell, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

interface WaiterCallSheetProps {
  isOpen: boolean;
  onClose: () => void;
  tableNumber: number;
  guestName: string;
}

const WAITER_REASONS = [
  { id: 'reason-water', label: '💧 Need Water', icon: '💧' },
  { id: 'reason-cutlery', label: '🍴 Extra Cutlery', icon: '🍴' },
  { id: 'reason-bill', label: '🧾 Request Bill', icon: '🧾' },
  { id: 'reason-help', label: '🙋 General Help', icon: '🙋' },
  { id: 'reason-condiment', label: '🧂 Condiments', icon: '🧂' },
  { id: 'reason-issue', label: '⚠️ Report Issue', icon: '⚠️' },
];

export default function WaiterCallSheet({
  isOpen,
  onClose,
  tableNumber,
  guestName,
}: WaiterCallSheetProps) {
  const [selectedReason, setSelectedReason] = useState('reason-water');
  const [isSent, setIsSent] = useState(false);
  const [isSending, setIsSending] = useState(false);

  const handleCall = async () => {
    setIsSending(true);
    // BACKEND INTEGRATION: POST /api/waiter-call { tableId: tableNumber, guestName, reason: selectedReason }
    await new Promise((r) => setTimeout(r, 800));
    setIsSending(false);
    setIsSent(true);
    toast.success('Waiter notified!', {
      description: `Someone will be at Table ${tableNumber} shortly.`,
    });
    setTimeout(() => {
      setIsSent(false);
      onClose();
    }, 2000);
  };

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        className="fixed bottom-0 left-0 right-0 z-50 max-w-lg mx-auto rounded-t-3xl overflow-hidden slide-up"
        style={{ background: 'var(--secondary)' }}
        role="dialog"
        aria-modal="true"
        aria-label="Call waiter"
      >
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full" style={{ background: 'rgba(255,255,255,0.2)' }} />
        </div>

        <div className="px-5 pt-3 pb-8 flex flex-col gap-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bell size={18} className="text-primary" />
              <h2 className="text-lg font-800 text-white">Call Waiter</h2>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full flex items-center justify-center"
              style={{ background: 'rgba(255,255,255,0.08)' }}
              aria-label="Close"
            >
              <X size={16} className="text-white" />
            </button>
          </div>

          <p className="text-sm text-muted-foreground">
            What do you need, <span className="text-white font-600">{guestName}</span>?
          </p>

          {isSent ? (
            <div className="flex flex-col items-center py-8 gap-3">
              <CheckCircle size={48} className="text-success" />
              <p className="text-base font-700 text-white">Waiter notified!</p>
              <p className="text-sm text-muted-foreground">
                Someone is on their way to Table {tableNumber}
              </p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-2">
                {WAITER_REASONS.map((reason) => {
                  const isSelected = selectedReason === reason.id;
                  return (
                    <button
                      key={reason.id}
                      onClick={() => setSelectedReason(reason.id)}
                      className="flex items-center gap-2 px-3 py-3 rounded-xl text-sm font-600 transition-all duration-150 active:scale-95 text-left"
                      style={
                        isSelected
                          ? {
                              background: 'rgba(255,92,0,0.15)',
                              border: '1.5px solid rgba(255,92,0,0.5)',
                              color: '#fff',
                            }
                          : {
                              background: 'rgba(255,255,255,0.04)',
                              border: '1.5px solid rgba(255,255,255,0.08)',
                              color: 'rgba(255,255,255,0.6)',
                            }
                      }
                    >
                      <span>{reason.icon}</span>
                      <span className="line-clamp-1">
                        {reason.label.replace(/^[^ ]+ /, '')}
                      </span>
                    </button>
                  );
                })}
              </div>

              <button
                onClick={handleCall}
                disabled={isSending}
                className="w-full flex items-center justify-center gap-2 py-4 rounded-xl text-base font-700 text-white transition-all duration-150 active:scale-95 disabled:opacity-60"
                style={{ background: 'linear-gradient(135deg, #FF5C00 0%, #FF7A2F 100%)' }}
              >
                {isSending ? (
                  <>
                    <svg className="animate-spin w-5 h-5" fill="none" viewBox="0 0 24 24" aria-hidden="true">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                    <span>Notifying...</span>
                  </>
                ) : (
                  <>
                    <Bell size={18} />
                    <span>🛎️ Call Waiter Now</span>
                  </>
                )}
              </button>
            </>
          )}
        </div>
      </div>
    </>
  );
}