'use client';

import React from 'react';
import { X, ShoppingBag, UtensilsCrossed, ChevronRight } from 'lucide-react';
import AppImage from '@/components/ui/AppImage';
import type { CartItem } from './MenuScreenWrapper';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onCheckout: () => void;
  totalValue: number;
}

const OTHER_TABLE_ITEMS = [
  { id: 'other-001', guest: 'Tunde', item: 'Fried Rice & Plantain', style: 'eat-in', price: 3200 },
  { id: 'other-002', guest: 'Amaka', item: 'Chapman', style: 'takeaway', price: 1200 },
  { id: 'other-003', guest: 'Seun', item: 'Grilled Chicken (Half)', style: 'eat-in', price: 3800 },
];

export default function CartDrawer({ isOpen, onClose, cartItems, onCheckout, totalValue }: CartDrawerProps) {
  const tableTotal =
    totalValue + OTHER_TABLE_ITEMS.reduce((sum, i) => sum + i.price, 0);

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        className="fixed bottom-0 left-0 right-0 z-50 max-w-lg mx-auto rounded-t-3xl overflow-hidden slide-up"
        style={{ background: 'var(--secondary)', maxHeight: '85vh' }}
        role="dialog"
        aria-modal="true"
        aria-label="Your cart"
      >
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full" style={{ background: 'rgba(255,255,255,0.2)' }} />
        </div>

        <div className="flex items-center justify-between px-5 py-3">
          <h2 className="text-lg font-800 text-white">Your Cart</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center transition-all active:scale-90"
            style={{ background: 'rgba(255,255,255,0.08)' }}
            aria-label="Close cart"
          >
            <X size={16} className="text-white" />
          </button>
        </div>

        <div className="overflow-y-auto px-5 pb-6" style={{ maxHeight: 'calc(85vh - 130px)' }}>
          {/* My Items */}
          <div className="flex flex-col gap-3 mb-5">
            <p className="text-xs font-700 uppercase tracking-widest text-muted-foreground">
              My Items
            </p>
            {cartItems.length === 0 ? (
              <div
                className="flex flex-col items-center py-8 gap-2 rounded-xl"
                style={{ background: 'rgba(255,255,255,0.03)' }}
              >
                <span className="text-3xl">🛒</span>
                <p className="text-sm text-muted-foreground">No items yet</p>
              </div>
            ) : (
              cartItems.map((ci) => (
                <div
                  key={ci.cartId}
                  className="flex items-center gap-3 p-3 rounded-xl"
                  style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}
                >
                  <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
                    <AppImage
                      src={ci.image}
                      alt={ci.imageAlt}
                      width={48}
                      height={48}
                      className="object-cover w-full h-full"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-700 text-white line-clamp-1">{ci.name}</p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="text-2xs text-muted-foreground">{ci.portionLabel}</span>
                      <span className="text-2xs text-muted-foreground">·</span>
                      {ci.serviceStyle === 'eat-in' ? (
                        <div className="flex items-center gap-0.5 text-2xs text-muted-foreground">
                          <UtensilsCrossed size={9} />
                          <span>Eat-in</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-0.5 text-2xs text-muted-foreground">
                          <ShoppingBag size={9} />
                          <span>Takeaway</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-0.5">
                    <span className="text-xs font-800 text-white tabular-nums">
                      ₦{(ci.portionPrice * ci.quantity).toLocaleString()}
                    </span>
                    <span className="text-2xs text-muted-foreground">×{ci.quantity}</span>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Table Summary */}
          <div className="flex flex-col gap-3 mb-5">
            <p className="text-xs font-700 uppercase tracking-widest text-muted-foreground">
              Table Summary
            </p>
            {OTHER_TABLE_ITEMS.map((oi) => (
              <div
                key={oi.id}
                className="flex items-center justify-between px-3 py-2.5 rounded-xl"
                style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.05)' }}
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-6 h-6 rounded-full flex items-center justify-center text-2xs font-800 text-white"
                    style={{ background: 'rgba(255,92,0,0.3)' }}
                  >
                    {oi.guest[0]}
                  </div>
                  <div className="flex flex-col gap-0">
                    <p className="text-xs font-600 text-white/70">{oi.guest}</p>
                    <p className="text-2xs text-muted-foreground line-clamp-1">{oi.item}</p>
                  </div>
                </div>
                <span className="text-xs font-700 text-white/60 tabular-nums">
                  ₦{oi.price.toLocaleString()}
                </span>
              </div>
            ))}
          </div>

          {/* Loyalty bar */}
          <div
            className="flex flex-col gap-2 p-3 rounded-xl mb-5"
            style={{ background: 'rgba(255,92,0,0.08)', border: '1px solid rgba(255,92,0,0.2)' }}
          >
            <div className="flex items-center justify-between">
              <p className="text-xs font-700 text-white/80">⭐ Forahia Points</p>
              <p className="text-xs font-700 text-primary">+150 pts on this order</p>
            </div>
            <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.1)' }}>
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: '62%', background: 'linear-gradient(90deg, #FF5C00, #FF7A2F)' }}
              />
            </div>
            <p className="text-2xs text-muted-foreground">310 / 500 pts to next reward</p>
          </div>

          {/* Totals */}
          <div
            className="flex flex-col gap-2 p-4 rounded-xl mb-4"
            style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}
          >
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>My items subtotal</span>
              <span className="tabular-nums">₦{totalValue.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Table total</span>
              <span className="tabular-nums">₦{tableTotal.toLocaleString()}</span>
            </div>
          </div>

          {/* Checkout CTA */}
          <button
            onClick={onCheckout}
            disabled={cartItems.length === 0}
            className="w-full flex items-center justify-between px-5 py-4 rounded-xl text-base font-700 text-white transition-all duration-150 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed orange-glow"
            style={{ background: 'linear-gradient(135deg, #FF5C00 0%, #FF7A2F 100%)' }}
          >
            <span>Proceed to Checkout</span>
            <div className="flex items-center gap-1">
              <span className="tabular-nums">₦{totalValue.toLocaleString()}</span>
              <ChevronRight size={16} />
            </div>
          </button>
        </div>
      </div>
    </>
  );
}