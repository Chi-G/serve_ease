'use client';

import React from 'react';
import { Bell, MapPin } from 'lucide-react';
import AppLogo from '@/components/ui/AppLogo';

interface MenuHeaderProps {
  tableNumber: number;
  guestName: string;
  onCallWaiter: () => void;
}

export default function MenuHeader({ tableNumber, guestName, onCallWaiter }: MenuHeaderProps) {
  return (
    <header
      className="sticky top-0 z-40 flex items-center justify-between px-4 py-3"
      style={{
        background: 'rgba(13,13,13,0.92)',
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
      }}
    >
      {/* Left: Logo + Table */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5">
          <AppLogo size={28} />
          <span className="text-sm font-700 text-white hidden sm:block">ServeEase</span>
        </div>
        <div
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full"
          style={{ background: 'rgba(255,92,0,0.12)', border: '1px solid rgba(255,92,0,0.25)' }}
        >
          <MapPin size={12} className="text-primary" />
          <span className="text-xs font-700 text-primary">Table {tableNumber}</span>
        </div>
      </div>

      {/* Center: Guest greeting */}
      <div className="flex flex-col items-center">
        <p className="text-2xs text-muted-foreground">Browsing as</p>
        <p className="text-xs font-700 text-white leading-tight">{guestName}</p>
      </div>

      {/* Right: Call Waiter */}
      <button
        onClick={onCallWaiter}
        className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-700 text-white transition-all duration-150 active:scale-95"
        style={{
          background: 'rgba(255,255,255,0.07)',
          border: '1px solid rgba(255,255,255,0.12)',
        }}
        aria-label="Call waiter"
      >
        <Bell size={14} className="text-primary" />
        <span className="hidden sm:block">Call Waiter</span>
        <span className="sm:hidden">🛎️</span>
      </button>
    </header>
  );
}