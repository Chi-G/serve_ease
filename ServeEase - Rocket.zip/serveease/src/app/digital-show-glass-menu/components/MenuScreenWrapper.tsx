'use client';

import React, { useState, useEffect, useRef } from 'react';
import { toast } from 'sonner';
import MenuHeader from './MenuHeader';
import CategoryChips from './CategoryChips';
import MenuSearchBar from './MenuSearchBar';
import MenuGrid from './MenuGrid';
import ProductDetailSheet from './ProductDetailSheet';
import CartFAB from './CartFAB';
import WaiterCallSheet from './WaiterCallSheet';
import GroupOrderBanner from './GroupOrderBanner';
import { MENU_ITEMS, CATEGORIES, type MenuItem } from './menuData';

export interface CartItem {
  cartId: string;
  itemId: string;
  name: string;
  portionLabel: string;
  portionPrice: number;
  quantity: number;
  serviceStyle: 'eat-in' | 'takeaway';
  image: string;
  imageAlt: string;
}

export default function MenuScreenWrapper() {
  const [activeCategory, setActiveCategory] = useState('cat-all');
  const [searchQuery, setSearchQuery] = useState('');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [isProductSheetOpen, setIsProductSheetOpen] = useState(false);
  const [isWaiterSheetOpen, setIsWaiterSheetOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [guestName, setGuestName] = useState('Guest');
  const cartFabRef = useRef<{ triggerBounce: () => void } | null>(null);

  useEffect(() => {
    // BACKEND INTEGRATION: GET /api/menu?tableId=12 — fetch live menu with stock status
    const timer = setTimeout(() => setIsLoading(false), 1200);
    const stored = localStorage.getItem('serveease_guest_name');
    if (stored) setGuestName(stored);
    return () => clearTimeout(timer);
  }, []);

  const filteredItems = MENU_ITEMS.filter((item) => {
    const matchesCategory =
      activeCategory === 'cat-all' ||
      CATEGORIES.find((c) => c.id === activeCategory)?.label === item.category;
    const matchesSearch =
      !searchQuery ||
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const totalCartItems = cartItems.reduce((sum, i) => sum + i.quantity, 0);
  const totalCartValue = cartItems.reduce(
    (sum, i) => sum + i.portionPrice * i.quantity,
    0
  );

  const handleItemClick = (item: MenuItem) => {
    if (item.status === 'sold-out') {
      toast.error(`${item.name} is sold out`, {
        description: 'Check back later or try something similar.',
      });
      return;
    }
    setSelectedItem(item);
    setIsProductSheetOpen(true);
  };

  const handleAddToCart = (cartItem: CartItem) => {
    setCartItems((prev) => {
      const existing = prev.find(
        (i) =>
          i.itemId === cartItem.itemId &&
          i.portionLabel === cartItem.portionLabel &&
          i.serviceStyle === cartItem.serviceStyle
      );
      if (existing) {
        return prev.map((i) =>
          i.cartId === existing.cartId
            ? { ...i, quantity: i.quantity + cartItem.quantity }
            : i
        );
      }
      return [...prev, cartItem];
    });
    cartFabRef.current?.triggerBounce();
    toast.success(`${cartItem.name} added to cart`, {
      description: `${cartItem.portionLabel} · ${cartItem.serviceStyle === 'eat-in' ? '🍽️ Eat-in' : '🥡 Takeaway'}`,
    });
  };

  const handleCallWaiter = () => {
    setIsWaiterSheetOpen(true);
    // BACKEND INTEGRATION: POST /api/waiter-call { tableId: 12, guestName, reason }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'var(--background)' }}>
      <MenuHeader
        tableNumber={12}
        guestName={guestName}
        onCallWaiter={handleCallWaiter}
      />

      <div className="flex-1 flex flex-col">
        {/* Search bar */}
        <div className="px-4 pt-4 pb-2">
          <MenuSearchBar value={searchQuery} onChange={setSearchQuery} />
        </div>

        {/* Group order banner */}
        <GroupOrderBanner guestName={guestName} />

        {/* Category chips */}
        <CategoryChips
          categories={CATEGORIES}
          activeCategory={activeCategory}
          onSelect={setActiveCategory}
        />

        {/* Menu grid */}
        <div className="flex-1 px-4 pb-32">
          <MenuGrid
            items={filteredItems}
            isLoading={isLoading}
            onItemClick={handleItemClick}
          />
        </div>
      </div>

      {/* Cart FAB */}
      <CartFAB
        ref={cartFabRef}
        itemCount={totalCartItems}
        totalValue={totalCartValue}
        cartItems={cartItems}
      />

      {/* Product detail bottom sheet */}
      {selectedItem && (
        <ProductDetailSheet
          item={selectedItem}
          isOpen={isProductSheetOpen}
          onClose={() => {
            setIsProductSheetOpen(false);
            setSelectedItem(null);
          }}
          onAddToCart={handleAddToCart}
          allItems={MENU_ITEMS}
        />
      )}

      {/* Waiter call sheet */}
      <WaiterCallSheet
        isOpen={isWaiterSheetOpen}
        onClose={() => setIsWaiterSheetOpen(false)}
        tableNumber={12}
        guestName={guestName}
      />
    </div>
  );
}