import MenuScreenWrapper from './components/MenuScreenWrapper';

export default function DigitalShowGlassMenuPage() {
  return <MenuScreenWrapper />;
}