// Join Table Portal — Entry screen (src/app/page.tsx)
import JoinTableContent from './components/JoinTableContent';

export default function JoinTablePortalPage() {
  return <JoinTableContent />;
}