import CheckoutHubWrapper from './components/CheckoutHubWrapper';

export default function CheckoutHubPage() {
  return <CheckoutHubWrapper />;
}