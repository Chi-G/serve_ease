export interface CheckoutCartItem {
  id: string;
  name: string;
  portionLabel: string;
  portionPrice: number;
  quantity: number;
  serviceStyle: 'eat-in' | 'takeaway';
  image: string;
  imageAlt: string;
}

export interface BankDetails {
  bankName: string;
  accountNumber: string;
  accountName: string;
}

export const MOCK_CART_ITEMS: CheckoutCartItem[] = [
{
  id: 'co-item-001',
  name: 'Party Jollof Rice',
  portionLabel: 'Medium',
  portionPrice: 3500,
  quantity: 1,
  serviceStyle: 'eat-in',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_181f54088-1777382429458.png",
  imageAlt: 'Steaming plate of orange-red jollof rice'
},
{
  id: 'co-item-002',
  name: 'Grilled Chicken',
  portionLabel: 'Half',
  portionPrice: 3800,
  quantity: 1,
  serviceStyle: 'eat-in',
  image: "https://images.unsplash.com/photo-1623246942993-803168b8a793",
  imageAlt: 'Golden-brown grilled chicken half with char marks'
},
{
  id: 'co-item-003',
  name: 'Chapman',
  portionLabel: 'Regular',
  portionPrice: 1200,
  quantity: 2,
  serviceStyle: 'eat-in',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_174e5ed13-1773153269845.png",
  imageAlt: 'Red Chapman cocktail in a tall glass with orange slice'
},
{
  id: 'co-item-004',
  name: 'Fried Plantain (Dodo)',
  portionLabel: 'Medium',
  portionPrice: 800,
  quantity: 1,
  serviceStyle: 'eat-in',
  image: "https://images.unsplash.com/photo-1627383574427-b258289835c8",
  imageAlt: 'Golden-yellow fried plantain slices on a white plate'
}];


export const BANK_DETAILS: BankDetails = {
  bankName: 'Wema Bank',
  accountNumber: '0123456789',
  accountName: 'FORAHIA KITCHEN LTD'
};

export const SERVICE_FEE = 150;
export const LOYALTY_POINTS_EARNED = 150;
export const LOYALTY_POINTS_CURRENT = 310;
export const LOYALTY_POINTS_TARGET = 500;