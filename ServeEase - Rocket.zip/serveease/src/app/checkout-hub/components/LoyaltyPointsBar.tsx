import React from 'react';
import { LOYALTY_POINTS_EARNED, LOYALTY_POINTS_CURRENT, LOYALTY_POINTS_TARGET } from './checkoutData';

export default function LoyaltyPointsBar() {
  const progress = Math.min(100, (LOYALTY_POINTS_CURRENT / LOYALTY_POINTS_TARGET) * 100);
  const remaining = LOYALTY_POINTS_TARGET - LOYALTY_POINTS_CURRENT;

  return (
    <div
      className="flex flex-col gap-3 p-4 rounded-2xl"
      style={{ background: 'rgba(255,92,0,0.07)', border: '1px solid rgba(255,92,0,0.18)' }}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-base">⭐</span>
          <p className="text-sm font-700 text-white">Forahia Points</p>
        </div>
        <div
          className="px-2.5 py-1 rounded-full text-xs font-700 text-primary"
          style={{ background: 'rgba(255,92,0,0.15)' }}
        >
          +{LOYALTY_POINTS_EARNED} pts this order
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>{LOYALTY_POINTS_CURRENT} pts</span>
          <span>{LOYALTY_POINTS_TARGET} pts</span>
        </div>
        <div className="h-2 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.1)' }}>
          <div
            className="h-full rounded-full transition-all duration-700"
            style={{
              width: `${progress}%`,
              background: 'linear-gradient(90deg, #FF5C00, #FF7A2F)',
            }}
          />
        </div>
        <p className="text-xs text-muted-foreground">
          {remaining} more points to unlock a free drink 🥤
        </p>
      </div>
    </div>
  );
}