'use client';

import React, { useState } from 'react';
import { ChevronDown, ChevronUp, UtensilsCrossed, ShoppingBag } from 'lucide-react';
import AppImage from '@/components/ui/AppImage';
import type { CheckoutCartItem } from './checkoutData';

interface OrderSummarySectionProps {
  items: CheckoutCartItem[];
  subtotal: number;
  serviceFee: number;
}

export default function OrderSummarySection({ items, subtotal, serviceFee }: OrderSummarySectionProps) {
  const [expanded, setExpanded] = useState(true);

  return (
    <div
      className="rounded-2xl overflow-hidden"
      style={{ background: 'var(--card)', border: '1px solid rgba(255,255,255,0.07)' }}
    >
      {/* Header */}
      <button
        onClick={() => setExpanded((e) => !e)}
        className="w-full flex items-center justify-between px-4 py-4 transition-colors hover:bg-white/5"
        aria-expanded={expanded}
      >
        <p className="text-sm font-700 text-white">Order Summary</p>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">
            {items.reduce((s, i) => s + i.quantity, 0)} items
          </span>
          {expanded ? (
            <ChevronUp size={16} className="text-muted-foreground" />
          ) : (
            <ChevronDown size={16} className="text-muted-foreground" />
          )}
        </div>
      </button>

      {expanded && (
        <div className="flex flex-col" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
          {/* Item list */}
          <div className="flex flex-col divide-y" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
            {items.map((item) => (
              <div key={item.id} className="flex items-center gap-3 px-4 py-3">
                <div className="w-10 h-10 rounded-lg overflow-hidden flex-shrink-0">
                  <AppImage
                    src={item.image}
                    alt={item.imageAlt}
                    width={40}
                    height={40}
                    className="object-cover w-full h-full"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-600 text-white line-clamp-1">{item.name}</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-2xs text-muted-foreground">{item.portionLabel}</span>
                    <span className="text-2xs text-muted-foreground">·</span>
                    {item.serviceStyle === 'eat-in' ? (
                      <div className="flex items-center gap-0.5 text-2xs text-muted-foreground">
                        <UtensilsCrossed size={9} />
                        <span>Eat-in</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-0.5 text-2xs text-muted-foreground">
                        <ShoppingBag size={9} />
                        <span>Takeaway</span>
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex flex-col items-end gap-0.5">
                  <span className="text-sm font-700 text-white tabular-nums">
                    ₦{(item.portionPrice * item.quantity).toLocaleString()}
                  </span>
                  {item.quantity > 1 && (
                    <span className="text-2xs text-muted-foreground">×{item.quantity}</span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Totals */}
          <div
            className="flex flex-col gap-2 px-4 py-3"
            style={{ borderTop: '1px solid rgba(255,255,255,0.06)', background: 'rgba(255,255,255,0.02)' }}
          >
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Subtotal</span>
              <span className="tabular-nums">₦{subtotal.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Service charge</span>
              <span className="tabular-nums">₦{serviceFee.toLocaleString()}</span>
            </div>
            <div
              className="flex items-center justify-between text-base font-800 text-white pt-2"
              style={{ borderTop: '1px solid rgba(255,255,255,0.08)' }}
            >
              <span>Total</span>
              <span className="tabular-nums text-primary">₦{(subtotal + serviceFee).toLocaleString()}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}