'use client';

import React from 'react';
import { ChevronLeft, MapPin } from 'lucide-react';
import AppLogo from '@/components/ui/AppLogo';

interface CheckoutHeaderProps {
  onBack: () => void;
  tableNumber: number;
}

export default function CheckoutHeader({ onBack, tableNumber }: CheckoutHeaderProps) {
  return (
    <header
      className="sticky top-0 z-40 flex items-center justify-between px-4 py-3"
      style={{
        background: 'rgba(13,13,13,0.92)',
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
      }}
    >
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-sm font-600 text-white/70 hover:text-white transition-colors active:scale-95"
        aria-label="Back to menu"
      >
        <ChevronLeft size={18} />
        <span>Menu</span>
      </button>

      <div className="flex items-center gap-2">
        <AppLogo size={24} />
        <span className="text-sm font-700 text-white">Checkout</span>
      </div>

      <div
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-full"
        style={{ background: 'rgba(255,92,0,0.12)', border: '1px solid rgba(255,92,0,0.25)' }}
      >
        <MapPin size={11} className="text-primary" />
        <span className="text-xs font-700 text-primary">Table {tableNumber}</span>
      </div>
    </header>
  );
}