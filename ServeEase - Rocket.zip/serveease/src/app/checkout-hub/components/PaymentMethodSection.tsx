'use client';

import React, { useState } from 'react';
import { CreditCard, Smartphone, Copy, CheckCircle, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { BANK_DETAILS } from './checkoutData';
import type { PaymentMethod, CheckoutState } from './CheckoutHubWrapper';

interface PaymentMethodSectionProps {
  selectedMethod: PaymentMethod;
  onSelect: (m: PaymentMethod) => void;
  checkoutState: CheckoutState;
  isProcessing: boolean;
  onPayNow: () => void;
  onVerifyTransfer: () => void;
  total: number;
}

export default function PaymentMethodSection({
  selectedMethod,
  onSelect,
  checkoutState,
  isProcessing,
  onPayNow,
  onVerifyTransfer,
  total,
}: PaymentMethodSectionProps) {
  const [copied, setCopied] = useState(false);

  const handleCopyAccount = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(BANK_DETAILS.accountNumber);
    }
    setCopied(true);
    toast.success('Account number copied!');
    setTimeout(() => setCopied(false), 3000);
  };

  const isVerifying = checkoutState === 'verifying';

  return (
    <div className="flex flex-col gap-3">
      <p className="text-sm font-700 text-white/80">Payment Method</p>

      {/* Method cards */}
      <div className="flex flex-col gap-2">
        {/* Card / USSD */}
        <button
          onClick={() => onSelect('card')}
          className="flex items-center gap-4 p-4 rounded-2xl text-left transition-all duration-200 active:scale-98"
          style={
            selectedMethod === 'card'
              ? {
                  background: 'rgba(255,92,0,0.1)',
                  border: '1.5px solid rgba(255,92,0,0.45)',
                }
              : {
                  background: 'var(--card)',
                  border: '1.5px solid rgba(255,255,255,0.08)',
                }
          }
        >
          <div
            className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{
              background: selectedMethod === 'card' ?'rgba(255,92,0,0.2)' :'rgba(255,255,255,0.06)',
            }}
          >
            <CreditCard size={20} className={selectedMethod === 'card' ? 'text-primary' : 'text-muted-foreground'} />
          </div>
          <div className="flex-1">
            <p className={`text-sm font-700 ${selectedMethod === 'card' ? 'text-white' : 'text-white/70'}`}>
              Card / USSD
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Instant — Visa, Mastercard, USSD shortcode
            </p>
          </div>
          <div
            className="w-5 h-5 rounded-full flex-shrink-0"
            style={{
              border: selectedMethod === 'card' ?'5px solid #FF5C00' :'2px solid rgba(255,255,255,0.2)',
            }}
          />
        </button>

        {/* Bank Transfer */}
        <button
          onClick={() => onSelect('transfer')}
          className="flex items-center gap-4 p-4 rounded-2xl text-left transition-all duration-200 active:scale-98"
          style={
            selectedMethod === 'transfer'
              ? {
                  background: 'rgba(255,92,0,0.1)',
                  border: '1.5px solid rgba(255,92,0,0.45)',
                }
              : {
                  background: 'var(--card)',
                  border: '1.5px solid rgba(255,255,255,0.08)',
                }
          }
        >
          <div
            className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{
              background: selectedMethod === 'transfer' ?'rgba(255,92,0,0.2)' :'rgba(255,255,255,0.06)',
            }}
          >
            <Smartphone size={20} className={selectedMethod === 'transfer' ? 'text-primary' : 'text-muted-foreground'} />
          </div>
          <div className="flex-1">
            <p className={`text-sm font-700 ${selectedMethod === 'transfer' ? 'text-white' : 'text-white/70'}`}>
              Bank Transfer
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Transfer to account — staff verifies receipt
            </p>
          </div>
          <div
            className="w-5 h-5 rounded-full flex-shrink-0"
            style={{
              border: selectedMethod === 'transfer' ?'5px solid #FF5C00' :'2px solid rgba(255,255,255,0.2)',
            }}
          />
        </button>
      </div>

      {/* Bank transfer details */}
      {selectedMethod === 'transfer' && (
        <div
          className="flex flex-col gap-3 p-4 rounded-2xl fade-in"
          style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}
        >
          <p className="text-xs font-700 uppercase tracking-widest text-muted-foreground">
            Transfer Details
          </p>
          <div className="flex flex-col gap-2.5">
            <div className="flex items-center justify-between">
              <div className="flex flex-col gap-0.5">
                <p className="text-2xs text-muted-foreground">Bank</p>
                <p className="text-sm font-700 text-white">{BANK_DETAILS.bankName}</p>
              </div>
            </div>
            <div
              className="flex items-center justify-between p-3 rounded-xl"
              style={{ background: 'rgba(255,92,0,0.08)', border: '1px solid rgba(255,92,0,0.2)' }}
            >
              <div className="flex flex-col gap-0.5">
                <p className="text-2xs text-muted-foreground">Account Number</p>
                <p className="text-xl font-800 text-white tabular-nums tracking-widest">
                  {BANK_DETAILS.accountNumber}
                </p>
                <p className="text-xs text-muted-foreground">{BANK_DETAILS.accountName}</p>
              </div>
              <button
                onClick={handleCopyAccount}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-700 transition-all active:scale-90"
                style={{
                  background: copied ? 'rgba(34,197,94,0.15)' : 'rgba(255,92,0,0.2)',
                  border: `1px solid ${copied ? 'rgba(34,197,94,0.4)' : 'rgba(255,92,0,0.4)'}`,
                  color: copied ? '#22C55E' : '#FF5C00',
                }}
                aria-label="Copy account number"
              >
                {copied ? <CheckCircle size={14} /> : <Copy size={14} />}
                <span>{copied ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex flex-col gap-0.5">
                <p className="text-2xs text-muted-foreground">Amount to Transfer</p>
                <p className="text-base font-800 text-primary tabular-nums">₦{total.toLocaleString()}</p>
              </div>
            </div>
          </div>

          <div
            className="flex items-start gap-2 p-3 rounded-xl"
            style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.2)' }}
          >
            <span className="text-sm flex-shrink-0">⚠️</span>
            <p className="text-xs text-warning/90 leading-relaxed">
              Transfer the exact amount shown above. After transferring, tap{' '}
              <span className="font-700">"I've Paid — Verify"</span> below. A staff member will
              confirm your payment within 2 minutes.
            </p>
          </div>
        </div>
      )}

      {/* CTA */}
      {isVerifying ? (
        <button
          onClick={onVerifyTransfer}
          disabled={isProcessing}
          className="w-full flex items-center justify-center gap-2 py-4 rounded-xl text-base font-700 text-white transition-all duration-150 active:scale-95 disabled:opacity-60"
          style={{ background: 'linear-gradient(135deg, #22C55E 0%, #16A34A 100%)' }}
        >
          {isProcessing ? (
            <>
              <svg className="animate-spin w-5 h-5" fill="none" viewBox="0 0 24 24" aria-hidden="true">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
              </svg>
              <span>Verifying Payment...</span>
            </>
          ) : (
            <>
              <CheckCircle size={18} />
              <span>I&apos;ve Paid — Verify</span>
            </>
          )}
        </button>
      ) : (
        <button
          onClick={onPayNow}
          disabled={isProcessing || checkoutState === 'paying'}
          className="w-full flex items-center justify-between px-5 py-4 rounded-xl text-base font-700 text-white transition-all duration-150 active:scale-95 disabled:opacity-60 orange-glow"
          style={{ background: 'linear-gradient(135deg, #FF5C00 0%, #FF7A2F 100%)' }}
        >
          {isProcessing ? (
            <div className="flex items-center justify-center gap-2 w-full">
              <svg className="animate-spin w-5 h-5" fill="none" viewBox="0 0 24 24" aria-hidden="true">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
              </svg>
              <span>Processing...</span>
            </div>
          ) : (
            <>
              <span>
                {selectedMethod === 'card' ? '💳 Pay Now' : '📱 Confirm Transfer'}
              </span>
              <div className="flex items-center gap-1.5">
                <span className="tabular-nums">₦{total.toLocaleString()}</span>
                <ArrowRight size={16} />
              </div>
            </>
          )}
        </button>
      )}
    </div>
  );
}