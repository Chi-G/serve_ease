'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import CheckoutHeader from './CheckoutHeader';
import OrderSummarySection from './OrderSummarySection';
import PaymentMethodSection from './PaymentMethodSection';
import LoyaltyPointsBar from './LoyaltyPointsBar';
import OrderTokenDisplay from './OrderTokenDisplay';
import { MOCK_CART_ITEMS, SERVICE_FEE, type CheckoutCartItem } from './checkoutData';

export type PaymentMethod = 'card' | 'transfer';
export type CheckoutState = 'review' | 'paying' | 'verifying' | 'confirmed';

export default function CheckoutHubWrapper() {
  const router = useRouter();
  const [cartItems, setCartItems] = useState<CheckoutCartItem[]>(MOCK_CART_ITEMS);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('transfer');
  const [checkoutState, setCheckoutState] = useState<CheckoutState>('review');
  const [guestName, setGuestName] = useState('Chijindu');
  const [orderToken, setOrderToken] = useState(42);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('serveease_guest_name');
    if (stored) setGuestName(stored);
    // BACKEND INTEGRATION: GET /api/cart?guestId=xxx — load persisted cart
    const storedCart = localStorage.getItem('serveease_cart');
    if (storedCart) {
      try {
        const parsed = JSON.parse(storedCart);
        if (Array.isArray(parsed) && parsed.length > 0) setCartItems(parsed);
      } catch {
        // fallback to mock data
      }
    }
  }, []);

  const subtotal = cartItems.reduce((s, i) => s + i.portionPrice * i.quantity, 0);
  const total = subtotal + SERVICE_FEE;

  const handlePayNow = async () => {
    setIsProcessing(true);
    setCheckoutState('paying');
    // BACKEND INTEGRATION: POST /api/orders/create { tableId: 12, guestName, items: cartItems, paymentMethod, total }
    // Returns: { orderId, tokenNumber, paymentReference }
    await new Promise((r) => setTimeout(r, 1800));
    if (paymentMethod === 'card') {
      setCheckoutState('confirmed');
    } else {
      setCheckoutState('verifying');
    }
    setIsProcessing(false);
  };

  const handleVerifyTransfer = async () => {
    setIsProcessing(true);
    // BACKEND INTEGRATION: POST /api/payments/verify { paymentReference, tableId: 12 }
    await new Promise((r) => setTimeout(r, 2000));
    setCheckoutState('confirmed');
    setIsProcessing(false);
  };

  if (checkoutState === 'confirmed') {
    return (
      <OrderTokenDisplay
        tokenNumber={orderToken}
        guestName={guestName}
        total={total}
        cartItems={cartItems}
        onBackToMenu={() => router.push('/digital-show-glass-menu')}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'var(--background)' }}>
      <CheckoutHeader
        onBack={() => router.push('/digital-show-glass-menu')}
        tableNumber={12}
      />

      <div className="flex-1 px-4 pb-36 pt-4 flex flex-col gap-5 max-w-lg mx-auto w-full">
        {/* Grand total hero */}
        <div
          className="flex flex-col items-center py-6 px-4 rounded-2xl gap-1"
          style={{
            background: 'linear-gradient(135deg, rgba(255,92,0,0.12) 0%, rgba(255,92,0,0.04) 100%)',
            border: '1px solid rgba(255,92,0,0.2)',
          }}
        >
          <p className="text-xs font-600 tracking-widest uppercase text-primary/70">
            Total Amount
          </p>
          <p
            className="tabular-nums font-800 text-white"
            style={{ fontSize: '42px', lineHeight: '1.1' }}
          >
            ₦{total.toLocaleString()}
          </p>
          <p className="text-xs text-muted-foreground">
            {cartItems.reduce((s, i) => s + i.quantity, 0)} items · Table 12 · incl. ₦{SERVICE_FEE} service charge
          </p>
        </div>

        {/* Order summary */}
        <OrderSummarySection items={cartItems} subtotal={subtotal} serviceFee={SERVICE_FEE} />

        {/* Payment method */}
        <PaymentMethodSection
          selectedMethod={paymentMethod}
          onSelect={setPaymentMethod}
          checkoutState={checkoutState}
          isProcessing={isProcessing}
          onPayNow={handlePayNow}
          onVerifyTransfer={handleVerifyTransfer}
          total={total}
        />

        {/* Loyalty */}
        <LoyaltyPointsBar />
      </div>
    </div>
  );
}