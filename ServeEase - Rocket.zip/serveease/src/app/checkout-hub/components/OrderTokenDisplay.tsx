'use client';

import React, { useState, useEffect } from 'react';
import { CheckCircle, ChevronRight, Bell } from 'lucide-react';
import type { CheckoutCartItem } from './checkoutData';

interface OrderTokenDisplayProps {
  tokenNumber: number;
  guestName: string;
  total: number;
  cartItems: CheckoutCartItem[];
  onBackToMenu: () => void;
}

type OrderStatus = 'paid' | 'kitchen' | 'ready';

const STATUS_STEPS: { id: OrderStatus; label: string; icon: string }[] = [
  { id: 'paid', label: 'Order Confirmed', icon: '✅' },
  { id: 'kitchen', label: 'In Kitchen', icon: '👨‍🍳' },
  { id: 'ready', label: 'Ready for Pickup', icon: '🍽️' },
];

export default function OrderTokenDisplay({
  tokenNumber,
  guestName,
  total,
  cartItems,
  onBackToMenu,
}: OrderTokenDisplayProps) {
  const [currentStatus, setCurrentStatus] = useState<OrderStatus>('paid');

  useEffect(() => {
    // BACKEND INTEGRATION: Subscribe to WebSocket/SSE for real-time order status updates
    // ws.on('order_status', (status) => setCurrentStatus(status))
    const t1 = setTimeout(() => setCurrentStatus('kitchen'), 4000);
    return () => clearTimeout(t1);
  }, []);

  const isReady = currentStatus === 'ready';
  const currentStepIndex = STATUS_STEPS.findIndex((s) => s.id === currentStatus);

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-between px-4 py-8 transition-all duration-700"
      style={{
        background: isReady
          ? 'linear-gradient(135deg, #052E16 0%, #0D0D0D 60%)'
          : 'var(--background)',
      }}
    >
      {/* Top section */}
      <div className="flex flex-col items-center gap-6 w-full max-w-sm pt-8">
        {/* Token display */}
        <div className="flex flex-col items-center gap-4">
          <p className="text-xs font-600 tracking-widest uppercase text-muted-foreground">
            Your Order Token
          </p>

          {/* Pulsing ring token */}
          <div className="relative flex items-center justify-center w-44 h-44">
            {/* Outer pulse ring */}
            <div
              className="absolute inset-0 rounded-full pulse-ring-outer"
              style={{
                border: `3px solid ${isReady ? '#22C55E' : '#FF5C00'}`,
              }}
              aria-hidden="true"
            />
            {/* Middle ring */}
            <div
              className="absolute inset-3 rounded-full pulse-ring"
              style={{
                border: `2px solid ${isReady ? 'rgba(34,197,94,0.4)' : 'rgba(255,92,0,0.4)'}`,
              }}
              aria-hidden="true"
            />
            {/* Token circle */}
            <div
              className="relative w-32 h-32 rounded-full flex flex-col items-center justify-center gap-0"
              style={{
                background: isReady
                  ? 'linear-gradient(135deg, #22C55E, #16A34A)'
                  : 'linear-gradient(135deg, #FF5C00, #FF7A2F)',
                boxShadow: isReady
                  ? '0 0 40px rgba(34,197,94,0.4), 0 0 80px rgba(34,197,94,0.15)'
                  : '0 0 40px rgba(255,92,0,0.4), 0 0 80px rgba(255,92,0,0.15)',
              }}
              role="status"
              aria-label={`Order token number ${tokenNumber}`}
            >
              <p className="text-xs font-600 text-white/70 uppercase tracking-widest">Token</p>
              <p
                className="tabular-nums font-800 text-white leading-none"
                style={{ fontSize: '52px' }}
              >
                #{String(tokenNumber).padStart(3, '0')}
              </p>
            </div>
          </div>

          <p className="text-sm text-muted-foreground text-center">
            Show this token to the waiter when collecting your order,{' '}
            <span className="font-700 text-white">{guestName}</span>
          </p>
        </div>

        {/* Status tracker */}
        <div
          className="w-full flex flex-col gap-4 p-5 rounded-2xl"
          style={{ background: 'var(--card)', border: '1px solid rgba(255,255,255,0.07)' }}
        >
          <p className="text-sm font-700 text-white">Order Status</p>

          <div className="flex items-center justify-between relative">
            {/* Progress line */}
            <div
              className="absolute top-5 left-5 right-5 h-0.5 rounded-full"
              style={{ background: 'rgba(255,255,255,0.1)' }}
              aria-hidden="true"/>
            {/* Active progress line */}
            <div
              className="absolute top-5 left-5 h-0.5 rounded-full transition-all duration-700"
              style={{
                background: isReady
                  ? '#22C55E' :'linear-gradient(90deg, #FF5C00, #FF7A2F)',
                width: currentStepIndex === 0 ? '0%' : currentStepIndex === 1 ? '50%' : '100%',
              }}
              aria-hidden="true"
            />

            {STATUS_STEPS.map((step, idx) => {
              const isDone = idx <= currentStepIndex;
              const isCurrent = idx === currentStepIndex;
              return (
                <div key={`step-${step.id}`} className="flex flex-col items-center gap-2 z-10">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-base transition-all duration-500"
                    style={
                      isDone
                        ? {
                            background: isReady
                              ? 'linear-gradient(135deg, #22C55E, #16A34A)'
                              : 'linear-gradient(135deg, #FF5C00, #FF7A2F)',
                            boxShadow: isCurrent
                              ? isReady
                                ? '0 0 16px rgba(34,197,94,0.5)'
                                : '0 0 16px rgba(255,92,0,0.5)' :'none',
                          }
                        : {
                            background: 'rgba(255,255,255,0.08)',
                            border: '1.5px solid rgba(255,255,255,0.12)',
                          }
                    }
                  >
                    {isDone ? (
                      idx < currentStepIndex ? (
                        <CheckCircle size={16} className="text-white" />
                      ) : (
                        <span>{step.icon}</span>
                      )
                    ) : (
                      <span style={{ opacity: 0.3 }}>{step.icon}</span>
                    )}
                  </div>
                  <p
                    className="text-2xs font-600 text-center leading-tight"
                    style={{ color: isDone ? '#fff' : 'rgba(255,255,255,0.3)', maxWidth: 72 }}
                  >
                    {step.label}
                  </p>
                </div>
              );
            })}
          </div>

          {isReady && (
            <div
              className="flex items-center gap-2 p-3 rounded-xl fade-in"
              style={{ background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.3)' }}
            >
              <Bell size={14} className="text-success flex-shrink-0" />
              <p className="text-xs font-600 text-success">
                Your order is ready! Show token #{String(tokenNumber).padStart(3, '0')} to the waiter.
              </p>
            </div>
          )}
        </div>

        {/* Order receipt summary */}
        <div
          className="w-full flex flex-col gap-2 p-4 rounded-2xl"
          style={{ background: 'var(--card)', border: '1px solid rgba(255,255,255,0.07)' }}
        >
          <p className="text-xs font-700 uppercase tracking-widest text-muted-foreground mb-1">
            What you ordered
          </p>
          {cartItems.map((item) => (
            <div key={`receipt-${item.id}`} className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground tabular-nums">
                  {item.quantity}×
                </span>
                <span className="text-sm text-white/80 font-500">{item.name}</span>
                <span className="text-2xs text-muted-foreground">({item.portionLabel})</span>
              </div>
              <span className="text-xs font-600 text-white/60 tabular-nums">
                ₦{(item.portionPrice * item.quantity).toLocaleString()}
              </span>
            </div>
          ))}
          <div
            className="flex items-center justify-between pt-2 mt-1"
            style={{ borderTop: '1px solid rgba(255,255,255,0.07)' }}
          >
            <span className="text-sm font-700 text-white">Total Paid</span>
            <span className="text-sm font-800 text-primary tabular-nums">
              ₦{total.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Bottom CTA */}
      <div className="w-full max-w-sm flex flex-col gap-3 pb-4">
        <button
          onClick={onBackToMenu}
          className="w-full flex items-center justify-center gap-2 py-4 rounded-xl text-sm font-700 transition-all duration-150 active:scale-95"
          style={{
            background: 'rgba(255,255,255,0.06)',
            border: '1px solid rgba(255,255,255,0.1)',
            color: 'rgba(255,255,255,0.7)',
          }}
        >
          <span>Order More Items</span>
          <ChevronRight size={16} />
        </button>
        <p className="text-center text-2xs text-muted-foreground">
          Powered by Forahia ServeEase · Table 12
        </p>
      </div>
    </div>
  );
}